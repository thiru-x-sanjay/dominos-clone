<!DOCTYPE html>
<html>
  <head>
    <title>Side Orders - Online Menu - Dominos India    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google-site-verification" content="z1BE_c3E8WBFb7r-0BxsSIUX1d4CyR93lxSivubuDdY" />
    <meta name="google-site-verification" content="2Q2xqQGZ28sWdxvZ_q30_A-YdL4GaX5D_1tiWw8THC4" />
    <meta name="google-site-verification" content="MlhCFaSUntPSOR5P2C20BxKlH82QAL1skCR1zEwo6kY" />
    <link rel="manifest" href="https://www.dominos.co.in/notifyvisitors_push/chrome/manifest.json">
    <link rel="canonical" href="https://www.dominos.co.in/theme2/front/js/form-fb.js"/>
    <meta charset="UTF-8">
    <meta content="IE=Edge" http-equiv="X-UA-Compatible"><script type="text/javascript">(window.NREUM||(NREUM={})).init={ajax:{deny_list:["bam.nr-data.net"]}};(window.NREUM||(NREUM={})).loader_config={licenseKey:"NRBR-3e999030a12e14fece2",applicationID:"685069429"};;/*! For license information please see nr-loader-rum-1.263.0.min.js.LICENSE.txt */
(()=>{var e,t,r={2983:(e,t,r)=>{"use strict";r.d(t,{D0:()=>m,gD:()=>y,Vp:()=>s,fr:()=>S,jD:()=>j,hR:()=>x,xN:()=>b,x1:()=>c,aN:()=>R,V:()=>I});var n=r(384),i=r(7864);const o={beacon:n.NT.beacon,errorBeacon:n.NT.errorBeacon,licenseKey:void 0,applicationID:void 0,sa:void 0,queueTime:void 0,applicationTime:void 0,ttGuid:void 0,user:void 0,account:void 0,product:void 0,extra:void 0,jsAttributes:{},userAttributes:void 0,atts:void 0,transactionName:void 0,tNamePlain:void 0},a={};function s(e){if(!e)throw new Error("All info objects require an agent identifier!");if(!a[e])throw new Error("Info for ".concat(e," was never set"));return a[e]}function c(e,t){if(!e)throw new Error("All info objects require an agent identifier!");a[e]=(0,i.a)(t,o);const r=(0,n.nY)(e);r&&(r.info=a[e])}var u=r(993);const l=e=>{if(!e||"string"!=typeof e)return!1;try{document.createDocumentFragment().querySelector(e)}catch{return!1}return!0};var d=r(2614),f=r(944);const g="[data-nr-mask]",p=()=>{const e={mask_selector:"*",block_selector:"[data-nr-block]",mask_input_options:{color:!1,date:!1,"datetime-local":!1,email:!1,month:!1,number:!1,range:!1,search:!1,tel:!1,text:!1,time:!1,url:!1,week:!1,textarea:!1,select:!1,password:!0}};return{ajax:{deny_list:void 0,block_internal:!0,enabled:!0,harvestTimeSeconds:10,autoStart:!0},distributed_tracing:{enabled:void 0,exclude_newrelic_header:void 0,cors_use_newrelic_header:void 0,cors_use_tracecontext_headers:void 0,allowed_origins:void 0},feature_flags:[],harvest:{tooManyRequestsDelay:60},jserrors:{enabled:!0,harvestTimeSeconds:10,autoStart:!0},logging:{enabled:!0,harvestTimeSeconds:10,autoStart:!0,level:u.p_.INFO},metrics:{enabled:!0,autoStart:!0},obfuscate:void 0,page_action:{enabled:!0,harvestTimeSeconds:30,autoStart:!0},page_view_event:{enabled:!0,autoStart:!0},page_view_timing:{enabled:!0,harvestTimeSeconds:30,long_task:!1,autoStart:!0},privacy:{cookies_enabled:!0},proxy:{assets:void 0,beacon:void 0},session:{expiresMs:d.wk,inactiveMs:d.BB},session_replay:{autoStart:!0,enabled:!1,harvestTimeSeconds:60,preload:!1,sampling_rate:10,error_sampling_rate:100,collect_fonts:!1,inline_images:!1,inline_stylesheet:!0,fix_stylesheets:!0,mask_all_inputs:!0,get mask_text_selector(){return e.mask_selector},set mask_text_selector(t){l(t)?e.mask_selector="".concat(t,",").concat(g):""===t||null===t?e.mask_selector=g:(0,f.R)(5,t)},get block_class(){return"nr-block"},get ignore_class(){return"nr-ignore"},get mask_text_class(){return"nr-mask"},get block_selector(){return e.block_selector},set block_selector(t){l(t)?e.block_selector+=",".concat(t):""!==t&&(0,f.R)(6,t)},get mask_input_options(){return e.mask_input_options},set mask_input_options(t){t&&"object"==typeof t?e.mask_input_options={...t,password:!0}:(0,f.R)(7,t)}},session_trace:{enabled:!0,harvestTimeSeconds:10,autoStart:!0},soft_navigations:{enabled:!0,harvestTimeSeconds:10,autoStart:!0},spa:{enabled:!0,harvestTimeSeconds:10,autoStart:!0},ssl:void 0}},h={},v="All configuration objects require an agent identifier!";function m(e){if(!e)throw new Error(v);if(!h[e])throw new Error("Configuration for ".concat(e," was never set"));return h[e]}function b(e,t){if(!e)throw new Error(v);h[e]=(0,i.a)(t,p());const r=(0,n.nY)(e);r&&(r.init=h[e])}function y(e,t){if(!e)throw new Error(v);var r=m(e);if(r){for(var n=t.split("."),i=0;i<n.length-1;i++)if("object"!=typeof(r=r[n[i]]))return;r=r[n[n.length-1]]}return r}const w={accountID:void 0,trustKey:void 0,agentID:void 0,licenseKey:void 0,applicationID:void 0,xpid:void 0},A={};function R(e,t){if(!e)throw new Error("All loader-config objects require an agent identifier!");A[e]=(0,i.a)(t,w);const r=(0,n.nY)(e);r&&(r.loader_config=A[e])}const x=(0,n.dV)().o;var E=r(6154),_=r(9324);const N={buildEnv:_.F3,distMethod:_.Xs,version:_.xv,originTime:E.WN},T={customTransaction:void 0,disabled:!1,isolatedBacklog:!1,loaderType:void 0,maxBytes:3e4,onerror:void 0,origin:""+E.gm.location,ptid:void 0,releaseIds:{},appMetadata:{},session:void 0,denyList:void 0,harvestCount:0,timeKeeper:void 0},k={};function S(e){if(!e)throw new Error("All runtime objects require an agent identifier!");if(!k[e])throw new Error("Runtime for ".concat(e," was never set"));return k[e]}function I(e,t){if(!e)throw new Error("All runtime objects require an agent identifier!");k[e]={...(0,i.a)(t,T),...N};const r=(0,n.nY)(e);r&&(r.runtime=k[e])}function j(e){return function(e){try{const t=s(e);return!!t.licenseKey&&!!t.errorBeacon&&!!t.applicationID}catch(e){return!1}}(e)}},7864:(e,t,r)=>{"use strict";r.d(t,{a:()=>i});var n=r(944);function i(e,t){try{if(!e||"object"!=typeof e)return(0,n.R)(3);if(!t||"object"!=typeof t)return(0,n.R)(4);const r=Object.create(Object.getPrototypeOf(t),Object.getOwnPropertyDescriptors(t)),o=0===Object.keys(r).length?e:r;for(let a in o)if(void 0!==e[a])try{if(null===e[a]){r[a]=null;continue}Array.isArray(e[a])&&Array.isArray(t[a])?r[a]=Array.from(new Set([...e[a],...t[a]])):"object"==typeof e[a]&&"object"==typeof t[a]?r[a]=i(e[a],t[a]):r[a]=e[a]}catch(e){(0,n.R)(1,e)}return r}catch(e){(0,n.R)(2,e)}}},9324:(e,t,r)=>{"use strict";r.d(t,{F3:()=>i,Xs:()=>o,xv:()=>n});const n="1.263.0",i="PROD",o="CDN"},6154:(e,t,r)=>{"use strict";r.d(t,{OF:()=>c,RI:()=>i,Vr:()=>d,WN:()=>f,bv:()=>o,gm:()=>a,lT:()=>l,mw:()=>s,sb:()=>u});var n=r(1863);const i="undefined"!=typeof window&&!!window.document,o="undefined"!=typeof WorkerGlobalScope&&("undefined"!=typeof self&&self instanceof WorkerGlobalScope&&self.navigator instanceof WorkerNavigator||"undefined"!=typeof globalThis&&globalThis instanceof WorkerGlobalScope&&globalThis.navigator instanceof WorkerNavigator),a=i?window:"undefined"!=typeof WorkerGlobalScope&&("undefined"!=typeof self&&self instanceof WorkerGlobalScope&&self||"undefined"!=typeof globalThis&&globalThis instanceof WorkerGlobalScope&&globalThis),s=Boolean("hidden"===a?.document?.visibilityState),c=/iPad|iPhone|iPod/.test(a.navigator?.userAgent),u=c&&"undefined"==typeof SharedWorker,l=((()=>{const e=a.navigator?.userAgent?.match(/Firefox[/\s](\d+\.\d+)/);Array.isArray(e)&&e.length>=2&&e[1]})(),Boolean(i&&window.document.documentMode)),d=!!a.navigator?.sendBeacon,f=Date.now()-(0,n.t)()},4777:(e,t,r)=>{"use strict";r.d(t,{J:()=>o});var n=r(944);const i={agentIdentifier:"",ee:void 0};class o{constructor(e){try{if("object"!=typeof e)return(0,n.R)(8);this.sharedContext={},Object.assign(this.sharedContext,i),Object.entries(e).forEach((e=>{let[t,r]=e;Object.keys(i).includes(t)&&(this.sharedContext[t]=r)}))}catch(e){(0,n.R)(9,e)}}}},1687:(e,t,r)=>{"use strict";r.d(t,{Ak:()=>c,Ze:()=>d,x3:()=>u});var n=r(7836),i=r(1478),o=r(3606),a=r(860);const s={};function c(e,t){const r={staged:!1,priority:a.P[t]||0};l(e),s[e].get(t)||s[e].set(t,r)}function u(e,t){e&&s[e]&&(s[e].get(t)&&s[e].delete(t),g(e,t,!1),s[e].size&&f(e))}function l(e){if(!e)throw new Error("agentIdentifier required");s[e]||(s[e]=new Map)}function d(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"",t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"feature",r=arguments.length>2&&void 0!==arguments[2]&&arguments[2];if(l(e),!e||!s[e].get(t)||r)return g(e,t);s[e].get(t).staged=!0,f(e)}function f(e){const t=Array.from(s[e]);t.every((e=>{let[t,r]=e;return r.staged}))&&(t.sort(((e,t)=>e[1].priority-t[1].priority)),t.forEach((t=>{let[r]=t;s[e].delete(r),g(e,r)})))}function g(e,t){let r=!(arguments.length>2&&void 0!==arguments[2])||arguments[2];const a=e?n.ee.get(e):n.ee,s=o.i.handlers;if(!a.aborted&&a.backlog&&s){if(r){const e=a.backlog[t],r=s[t];if(r){for(let t=0;e&&t<e.length;++t)p(e[t],r);(0,i.$)(r,(function(e,t){(0,i.$)(t,(function(t,r){r[0].on(e,r[1])}))}))}}a.isolatedBacklog||delete s[t],a.backlog[t]=null,a.emit("drain-"+t,[])}}function p(e,t){var r=e[1];(0,i.$)(t[r],(function(t,r){var n=e[0];if(r[0]===n){var i=r[1],o=e[3],a=e[2];i.apply(o,a)}}))}},7836:(e,t,r)=>{"use strict";r.d(t,{P:()=>c,ee:()=>u});var n=r(384),i=r(8990),o=r(2983),a=r(2646),s=r(5607);const c="nr@context:".concat(s.W),u=function e(t,r){var n={},s={},l={},d=!1;try{d=16===r.length&&(0,o.fr)(r).isolatedBacklog}catch(e){}var f={on:p,addEventListener:p,removeEventListener:function(e,t){var r=n[e];if(!r)return;for(var i=0;i<r.length;i++)r[i]===t&&r.splice(i,1)},emit:function(e,r,n,i,o){!1!==o&&(o=!0);if(u.aborted&&!i)return;t&&o&&t.emit(e,r,n);for(var a=g(n),c=h(e),l=c.length,d=0;d<l;d++)c[d].apply(a,r);var p=m()[s[e]];p&&p.push([f,e,r,a]);return a},get:v,listeners:h,context:g,buffer:function(e,t){const r=m();if(t=t||"feature",f.aborted)return;Object.entries(e||{}).forEach((e=>{let[n,i]=e;s[i]=t,t in r||(r[t]=[])}))},abort:function(){f._aborted=!0,Object.keys(f.backlog).forEach((e=>{delete f.backlog[e]}))},isBuffering:function(e){return!!m()[s[e]]},debugId:r,backlog:d?{}:t&&"object"==typeof t.backlog?t.backlog:{},isolatedBacklog:d};return Object.defineProperty(f,"aborted",{get:()=>{let e=f._aborted||!1;return e||(t&&(e=t.aborted),e)}}),f;function g(e){return e&&e instanceof a.y?e:e?(0,i.I)(e,c,(()=>new a.y(c))):new a.y(c)}function p(e,t){n[e]=h(e).concat(t)}function h(e){return n[e]||[]}function v(t){return l[t]=l[t]||e(f,t)}function m(){return f.backlog}}(void 0,"globalEE"),l=(0,n.Zm)();l.ee||(l.ee=u)},2646:(e,t,r)=>{"use strict";r.d(t,{y:()=>n});class n{constructor(e){this.contextId=e}}},9908:(e,t,r)=>{"use strict";r.d(t,{d:()=>n,p:()=>i});var n=r(7836).ee.get("handle");function i(e,t,r,i,o){o?(o.buffer([e],i),o.emit(e,t,r)):(n.buffer([e],i),n.emit(e,t,r))}},3606:(e,t,r)=>{"use strict";r.d(t,{i:()=>o});var n=r(9908);o.on=a;var i=o.handlers={};function o(e,t,r,o){a(o||n.d,i,e,t,r)}function a(e,t,r,i,o){o||(o="feature"),e||(e=n.d);var a=t[o]=t[o]||{};(a[r]=a[r]||[]).push([e,i])}},3878:(e,t,r)=>{"use strict";r.d(t,{DD:()=>c,jT:()=>a,sp:()=>s});var n=r(6154);let i=!1,o=!1;try{const e={get passive(){return i=!0,!1},get signal(){return o=!0,!1}};n.gm.addEventListener("test",null,e),n.gm.removeEventListener("test",null,e)}catch(e){}function a(e,t){return i||o?{capture:!!e,passive:i,signal:t}:!!e}function s(e,t){let r=arguments.length>2&&void 0!==arguments[2]&&arguments[2],n=arguments.length>3?arguments[3]:void 0;window.addEventListener(e,t,a(r,n))}function c(e,t){let r=arguments.length>2&&void 0!==arguments[2]&&arguments[2],n=arguments.length>3?arguments[3]:void 0;document.addEventListener(e,t,a(r,n))}},5607:(e,t,r)=>{"use strict";r.d(t,{W:()=>n});const n=(0,r(9566).bz)()},9566:(e,t,r)=>{"use strict";r.d(t,{LA:()=>s,bz:()=>a});var n=r(6154);const i="xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx";function o(e,t){return e?15&e[t]:16*Math.random()|0}function a(){const e=n.gm?.crypto||n.gm?.msCrypto;let t,r=0;return e&&e.getRandomValues&&(t=e.getRandomValues(new Uint8Array(30))),i.split("").map((e=>"x"===e?o(t,r++).toString(16):"y"===e?(3&o()|8).toString(16):e)).join("")}function s(e){const t=n.gm?.crypto||n.gm?.msCrypto;let r,i=0;t&&t.getRandomValues&&(r=t.getRandomValues(new Uint8Array(e)));const a=[];for(var s=0;s<e;s++)a.push(o(r,i++).toString(16));return a.join("")}},2614:(e,t,r)=>{"use strict";r.d(t,{BB:()=>a,H3:()=>n,g:()=>u,iL:()=>c,tS:()=>s,uh:()=>i,wk:()=>o});const n="NRBA",i="SESSION",o=144e5,a=18e5,s={STARTED:"session-started",PAUSE:"session-pause",RESET:"session-reset",RESUME:"session-resume",UPDATE:"session-update"},c={SAME_TAB:"same-tab",CROSS_TAB:"cross-tab"},u={OFF:0,FULL:1,ERROR:2}},1863:(e,t,r)=>{"use strict";function n(){return Math.floor(performance.now())}r.d(t,{t:()=>n})},944:(e,t,r)=>{"use strict";function n(e,t){"function"==typeof console.debug&&console.debug("New Relic Warning: https://github.com/newrelic/newrelic-browser-agent/blob/main/docs/warning-codes.md#".concat(e),t)}r.d(t,{R:()=>n})},5284:(e,t,r)=>{"use strict";r.d(t,{t:()=>c,B:()=>s});var n=r(7836),i=r(6154);const o="newrelic";const a=new Set,s={};function c(e,t){const r=n.ee.get(t);s[t]??={},e&&"object"==typeof e&&(a.has(t)||(r.emit("rumresp",[e]),s[t]=e,a.add(t),function(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};try{i.gm.dispatchEvent(new CustomEvent(o,{detail:e}))}catch(e){}}({loaded:!0})))}},8990:(e,t,r)=>{"use strict";r.d(t,{I:()=>i});var n=Object.prototype.hasOwnProperty;function i(e,t,r){if(n.call(e,t))return e[t];var i=r();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,t,{value:i,writable:!0,enumerable:!1}),i}catch(e){}return e[t]=i,i}},6389:(e,t,r)=>{"use strict";function n(e){var t=this;let r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:500,n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};const i=n?.leading||!1;let o;return function(){for(var n=arguments.length,a=new Array(n),s=0;s<n;s++)a[s]=arguments[s];i&&void 0===o&&(e.apply(t,a),o=setTimeout((()=>{o=clearTimeout(o)}),r)),i||(clearTimeout(o),o=setTimeout((()=>{e.apply(t,a)}),r))}}function i(e){var t=this;let r=!1;return function(){if(!r){r=!0;for(var n=arguments.length,i=new Array(n),o=0;o<n;o++)i[o]=arguments[o];e.apply(t,i)}}}r.d(t,{J:()=>i,s:()=>n})},1478:(e,t,r)=>{"use strict";r.d(t,{$:()=>n});const n=(e,t)=>Object.entries(e||{}).map((e=>{let[r,n]=e;return t(r,n)}))},5289:(e,t,r)=>{"use strict";r.d(t,{GG:()=>o,sB:()=>a});var n=r(3878);function i(){return"undefined"==typeof document||"complete"===document.readyState}function o(e,t){if(i())return e();(0,n.sp)("load",e,t)}function a(e){if(i())return e();(0,n.DD)("DOMContentLoaded",e)}},384:(e,t,r)=>{"use strict";r.d(t,{NT:()=>o,US:()=>l,Zm:()=>a,bQ:()=>c,dV:()=>s,nY:()=>u,pV:()=>d});var n=r(6154),i=r(1863);const o={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net"};function a(){return n.gm.NREUM||(n.gm.NREUM={}),void 0===n.gm.newrelic&&(n.gm.newrelic=n.gm.NREUM),n.gm.NREUM}function s(){let e=a();return e.o||(e.o={ST:n.gm.setTimeout,SI:n.gm.setImmediate,CT:n.gm.clearTimeout,XHR:n.gm.XMLHttpRequest,REQ:n.gm.Request,EV:n.gm.Event,PR:n.gm.Promise,MO:n.gm.MutationObserver,FETCH:n.gm.fetch}),e}function c(e,t){let r=a();r.initializedAgents??={},t.initializedAt={ms:(0,i.t)(),date:new Date},r.initializedAgents[e]=t}function u(e){let t=a();return t.initializedAgents?.[e]}function l(e,t){a()[e]=t}function d(){return function(){let e=a();const t=e.info||{};e.info={beacon:o.beacon,errorBeacon:o.errorBeacon,...t}}(),function(){let e=a();const t=e.init||{};e.init={...t}}(),s(),function(){let e=a();const t=e.loader_config||{};e.loader_config={...t}}(),a()}},2843:(e,t,r)=>{"use strict";r.d(t,{u:()=>i});var n=r(3878);function i(e){let t=arguments.length>1&&void 0!==arguments[1]&&arguments[1],r=arguments.length>2?arguments[2]:void 0,i=arguments.length>3?arguments[3]:void 0;(0,n.DD)("visibilitychange",(function(){if(t)return void("hidden"===document.visibilityState&&e());e(document.visibilityState)}),r,i)}},3434:(e,t,r)=>{"use strict";r.d(t,{YM:()=>c});var n=r(7836),i=r(5607);const o="nr@original:".concat(i.W);var a=Object.prototype.hasOwnProperty,s=!1;function c(e,t){return e||(e=n.ee),r.inPlace=function(e,t,n,i,o){n||(n="");const a="-"===n.charAt(0);for(let s=0;s<t.length;s++){const c=t[s],u=e[c];l(u)||(e[c]=r(u,a?c+n:n,i,c,o))}},r.flag=o,r;function r(t,r,n,s,c){return l(t)?t:(r||(r=""),nrWrapper[o]=t,function(e,t,r){if(Object.defineProperty&&Object.keys)try{return Object.keys(e).forEach((function(r){Object.defineProperty(t,r,{get:function(){return e[r]},set:function(t){return e[r]=t,t}})})),t}catch(e){u([e],r)}for(var n in e)a.call(e,n)&&(t[n]=e[n])}(t,nrWrapper,e),nrWrapper);function nrWrapper(){var o,a,l,d;try{a=this,o=[...arguments],l="function"==typeof n?n(o,a):n||{}}catch(t){u([t,"",[o,a,s],l],e)}i(r+"start",[o,a,s],l,c);try{return d=t.apply(a,o)}catch(e){throw i(r+"err",[o,a,e],l,c),e}finally{i(r+"end",[o,a,d],l,c)}}}function i(r,n,i,o){if(!s||t){var a=s;s=!0;try{e.emit(r,n,i,t,o)}catch(t){u([t,r,n,i],e)}s=a}}}function u(e,t){t||(t=n.ee);try{t.emit("internal-error",e)}catch(e){}}function l(e){return!(e&&"function"==typeof e&&e.apply&&!e[o])}},993:(e,t,r)=>{"use strict";r.d(t,{ET:()=>o,p_:()=>i});var n=r(860);const i={ERROR:"ERROR",WARN:"WARN",INFO:"INFO",DEBUG:"DEBUG",TRACE:"TRACE"},o="log";n.K.logging},3969:(e,t,r)=>{"use strict";r.d(t,{TZ:()=>n,XG:()=>s,rs:()=>i,xV:()=>a,z_:()=>o});const n=r(860).K.metrics,i="sm",o="cm",a="storeSupportabilityMetrics",s="storeEventMetrics"},6630:(e,t,r)=>{"use strict";r.d(t,{T:()=>n});const n=r(860).K.pageViewEvent},782:(e,t,r)=>{"use strict";r.d(t,{T:()=>n});const n=r(860).K.pageViewTiming},6344:(e,t,r)=>{"use strict";r.d(t,{G4:()=>i});var n=r(2614);r(860).K.sessionReplay;const i={RECORD:"recordReplay",PAUSE:"pauseReplay",REPLAY_RUNNING:"replayRunning",ERROR_DURING_REPLAY:"errorDuringReplay"};n.g.ERROR,n.g.FULL,n.g.OFF},4234:(e,t,r)=>{"use strict";r.d(t,{W:()=>i});var n=r(7836);class i{constructor(e,t,r){this.agentIdentifier=e,this.aggregator=t,this.ee=n.ee.get(e),this.featureName=r,this.blocked=!1}}},2266:(e,t,r)=>{"use strict";r.d(t,{j:()=>k});var n=r(860),i=r(2983),o=r(9908),a=r(7836),s=r(1687),c=r(5289),u=r(6154),l=r(944),d=r(3969),f=r(384),g=r(6344);const p=["setErrorHandler","finished","addToTrace","addRelease","addPageAction","setCurrentRouteName","setPageViewName","setCustomAttribute","interaction","noticeError","setUserId","setApplicationVersion","start",g.G4.RECORD,g.G4.PAUSE,"log","wrapLogger"],h=["setErrorHandler","finished","addToTrace","addRelease"];var v=r(1863),m=r(2614),b=r(993);var y=r(2646),w=r(3434);function A(e,t,r,n){if("object"!=typeof t||!t||"string"!=typeof r||!r||"function"!=typeof t[r])return(0,l.R)(29);const i=function(e){return(e||a.ee).get("logger")}(e),o=(0,w.YM)(i),s=new y.y(a.P);return s.level=n.level,s.customAttributes=n.customAttributes,o.inPlace(t,[r],"wrap-logger-",s),i}function R(){const e=(0,f.pV)();p.forEach((t=>{e[t]=function(){for(var r=arguments.length,n=new Array(r),i=0;i<r;i++)n[i]=arguments[i];return function(t){for(var r=arguments.length,n=new Array(r>1?r-1:0),i=1;i<r;i++)n[i-1]=arguments[i];let o=[];return Object.values(e.initializedAgents).forEach((e=>{e&&e.api?e.exposed&&e.api[t]&&o.push(e.api[t](...n)):(0,l.R)(38,t)})),o.length>1?o:o[0]}(t,...n)}}))}const x={};function E(e,t){let f=arguments.length>2&&void 0!==arguments[2]&&arguments[2];t||(0,s.Ak)(e,"api");const p={};var y=a.ee.get(e),w=y.get("tracer");x[e]=m.g.OFF,y.on(g.G4.REPLAY_RUNNING,(t=>{x[e]=t}));var R="api-",E=R+"ixn-";function _(t,r,n,o){const a=(0,i.Vp)(e);return null===r?delete a.jsAttributes[t]:(0,i.x1)(e,{...a,jsAttributes:{...a.jsAttributes,[t]:r}}),k(R,n,!0,o||null===r?"session":void 0)(t,r)}function N(){}p.log=function(e){let{customAttributes:t={},level:r=b.p_.INFO}=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};(0,o.p)(d.xV,["API/log/called"],void 0,n.K.metrics,y),function(e,t){let r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},i=arguments.length>3&&void 0!==arguments[3]?arguments[3]:b.p_.INFO;(0,o.p)(d.xV,["API/logging/".concat(i.toLowerCase(),"/called")],void 0,n.K.metrics,e),(0,o.p)(b.ET,[(0,v.t)(),t,r,i],void 0,n.K.logging,e)}(y,e,t,r)},p.wrapLogger=function(e,t){let{customAttributes:r={},level:i=b.p_.INFO}=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};(0,o.p)(d.xV,["API/wrapLogger/called"],void 0,n.K.metrics,y),A(y,e,t,{customAttributes:r,level:i})},h.forEach((e=>{p[e]=k(R,e,!0,"api")})),p.addPageAction=k(R,"addPageAction",!0,n.K.pageAction),p.setPageViewName=function(t,r){if("string"==typeof t)return"/"!==t.charAt(0)&&(t="/"+t),(0,i.fr)(e).customTransaction=(r||"http://custom.transaction")+t,k(R,"setPageViewName",!0)()},p.setCustomAttribute=function(e,t){let r=arguments.length>2&&void 0!==arguments[2]&&arguments[2];if("string"==typeof e){if(["string","number","boolean"].includes(typeof t)||null===t)return _(e,t,"setCustomAttribute",r);(0,l.R)(40,typeof t)}else(0,l.R)(39,typeof e)},p.setUserId=function(e){if("string"==typeof e||null===e)return _("enduser.id",e,"setUserId",!0);(0,l.R)(41,typeof e)},p.setApplicationVersion=function(e){if("string"==typeof e||null===e)return _("application.version",e,"setApplicationVersion",!1);(0,l.R)(42,typeof e)},p.start=()=>{try{(0,o.p)(d.xV,["API/start/called"],void 0,n.K.metrics,y),y.emit("manual-start-all")}catch(e){(0,l.R)(23,e)}},p[g.G4.RECORD]=function(){(0,o.p)(d.xV,["API/recordReplay/called"],void 0,n.K.metrics,y),(0,o.p)(g.G4.RECORD,[],void 0,n.K.sessionReplay,y)},p[g.G4.PAUSE]=function(){(0,o.p)(d.xV,["API/pauseReplay/called"],void 0,n.K.metrics,y),(0,o.p)(g.G4.PAUSE,[],void 0,n.K.sessionReplay,y)},p.interaction=function(e){return(new N).get("object"==typeof e?e:{})};const T=N.prototype={createTracer:function(e,t){var r={},i=this,a="function"==typeof t;return(0,o.p)(d.xV,["API/createTracer/called"],void 0,n.K.metrics,y),f||(0,o.p)(E+"tracer",[(0,v.t)(),e,r],i,n.K.spa,y),function(){if(w.emit((a?"":"no-")+"fn-start",[(0,v.t)(),i,a],r),a)try{return t.apply(this,arguments)}catch(e){const t="string"==typeof e?new Error(e):e;throw w.emit("fn-err",[arguments,this,t],r),t}finally{w.emit("fn-end",[(0,v.t)()],r)}}}};function k(e,t,r,i){return function(){return(0,o.p)(d.xV,["API/"+t+"/called"],void 0,n.K.metrics,y),i&&(0,o.p)(e+t,[(0,v.t)(),...arguments],r?null:this,i,y),r?void 0:this}}function S(){r.e(296).then(r.bind(r,8778)).then((t=>{let{setAPI:r}=t;r(e),(0,s.Ze)(e,"api")})).catch((e=>{(0,l.R)(27,e),y.abort()}))}return["actionText","setName","setAttribute","save","ignore","onEnd","getContext","end","get"].forEach((e=>{T[e]=k(E,e,void 0,f?n.K.softNav:n.K.spa)})),p.setCurrentRouteName=f?k(E,"routeName",void 0,n.K.softNav):k(R,"routeName",!0,n.K.spa),p.noticeError=function(t,r){"string"==typeof t&&(t=new Error(t)),(0,o.p)(d.xV,["API/noticeError/called"],void 0,n.K.metrics,y),(0,o.p)("err",[t,(0,v.t)(),!1,r,!!x[e]],void 0,n.K.jserrors,y)},u.RI?(0,c.GG)((()=>S()),!0):S(),p}var _=r(5284);const N=e=>{const t=e.startsWith("http");e+="/",r.p=t?e:"https://"+e};let T=!1;function k(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},r=arguments.length>2?arguments[2]:void 0,n=arguments.length>3?arguments[3]:void 0,{init:o,info:a,loader_config:s,runtime:c={loaderType:r},exposed:l=!0}=t;const d=(0,f.pV)();a||(o=d.init,a=d.info,s=d.loader_config),(0,i.xN)(e.agentIdentifier,o||{}),(0,i.aN)(e.agentIdentifier,s||{}),a.jsAttributes??={},u.bv&&(a.jsAttributes.isWorker=!0),(0,i.x1)(e.agentIdentifier,a);const g=(0,i.D0)(e.agentIdentifier),p=[a.beacon,a.errorBeacon];T||(g.proxy.assets&&(N(g.proxy.assets),p.push(g.proxy.assets)),g.proxy.beacon&&p.push(g.proxy.beacon),R(),(0,f.US)("activatedFeatures",_.B),e.runSoftNavOverSpa&&=!0===g.soft_navigations.enabled&&g.feature_flags.includes("soft_nav")),c.denyList=[...g.ajax.deny_list||[],...g.ajax.block_internal?p:[]],c.ptid=e.agentIdentifier,(0,i.V)(e.agentIdentifier,c),void 0===e.api&&(e.api=E(e.agentIdentifier,n,e.runSoftNavOverSpa)),void 0===e.exposed&&(e.exposed=l),T=!0}},8374:(e,t,r)=>{r.nc=(()=>{try{return document?.currentScript?.nonce}catch(e){}return""})()},860:(e,t,r)=>{"use strict";r.d(t,{K:()=>n,P:()=>i});const n={ajax:"ajax",jserrors:"jserrors",logging:"logging",metrics:"metrics",pageAction:"page_action",pageViewEvent:"page_view_event",pageViewTiming:"page_view_timing",sessionReplay:"session_replay",sessionTrace:"session_trace",softNav:"soft_navigations",spa:"spa"},i={[n.pageViewEvent]:1,[n.pageViewTiming]:2,[n.metrics]:3,[n.jserrors]:4,[n.spa]:5,[n.ajax]:6,[n.sessionTrace]:7,[n.pageAction]:8,[n.softNav]:9,[n.sessionReplay]:10,[n.logging]:11}}},n={};function i(e){var t=n[e];if(void 0!==t)return t.exports;var o=n[e]={exports:{}};return r[e](o,o.exports,i),o.exports}i.m=r,i.d=(e,t)=>{for(var r in t)i.o(t,r)&&!i.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},i.f={},i.e=e=>Promise.all(Object.keys(i.f).reduce(((t,r)=>(i.f[r](e,t),t)),[])),i.u=e=>"nr-rum-1.263.0.min.js",i.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),e={},t="NRBA-1.263.0.PROD:",i.l=(r,n,o,a)=>{if(e[r])e[r].push(n);else{var s,c;if(void 0!==o)for(var u=document.getElementsByTagName("script"),l=0;l<u.length;l++){var d=u[l];if(d.getAttribute("src")==r||d.getAttribute("data-webpack")==t+o){s=d;break}}if(!s){c=!0;var f={296:"sha512-TBs8pRY/W1e4YzgroQONE2LdGjV5O7juw1SF7NvOnee+rj/znproh6CPX2kHL0dyqMqLl4mpTclA+3nAiAWZaQ=="};(s=document.createElement("script")).charset="utf-8",s.timeout=120,i.nc&&s.setAttribute("nonce",i.nc),s.setAttribute("data-webpack",t+o),s.src=r,0!==s.src.indexOf(window.location.origin+"/")&&(s.crossOrigin="anonymous"),f[a]&&(s.integrity=f[a])}e[r]=[n];var g=(t,n)=>{s.onerror=s.onload=null,clearTimeout(p);var i=e[r];if(delete e[r],s.parentNode&&s.parentNode.removeChild(s),i&&i.forEach((e=>e(n))),t)return t(n)},p=setTimeout(g.bind(null,void 0,{type:"timeout",target:s}),12e4);s.onerror=g.bind(null,s.onerror),s.onload=g.bind(null,s.onload),c&&document.head.appendChild(s)}},i.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},i.p="https://js-agent.newrelic.com/",(()=>{var e={840:0,374:0};i.f.j=(t,r)=>{var n=i.o(e,t)?e[t]:void 0;if(0!==n)if(n)r.push(n[2]);else{var o=new Promise(((r,i)=>n=e[t]=[r,i]));r.push(n[2]=o);var a=i.p+i.u(t),s=new Error;i.l(a,(r=>{if(i.o(e,t)&&(0!==(n=e[t])&&(e[t]=void 0),n)){var o=r&&("load"===r.type?"missing":r.type),a=r&&r.target&&r.target.src;s.message="Loading chunk "+t+" failed.\n("+o+": "+a+")",s.name="ChunkLoadError",s.type=o,s.request=a,n[1](s)}}),"chunk-"+t,t)}};var t=(t,r)=>{var n,o,[a,s,c]=r,u=0;if(a.some((t=>0!==e[t]))){for(n in s)i.o(s,n)&&(i.m[n]=s[n]);if(c)c(i)}for(t&&t(r);u<a.length;u++)o=a[u],i.o(e,o)&&e[o]&&e[o][0](),e[o]=0},r=self["webpackChunk:NRBA-1.263.0.PROD"]=self["webpackChunk:NRBA-1.263.0.PROD"]||[];r.forEach(t.bind(null,0)),r.push=t.bind(null,r.push.bind(r))})(),(()=>{"use strict";i(8374);var e=i(944),t=i(6344),r=i(9566),n=i(7836);class o{agentIdentifier;constructor(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,r.LA)(16);this.agentIdentifier=e,this.ee=n.ee.get(e)}#e(t){for(var r=arguments.length,n=new Array(r>1?r-1:0),i=1;i<r;i++)n[i-1]=arguments[i];if("function"==typeof this.api?.[t])return this.api[t](...n);(0,e.R)(35,t)}addPageAction(e,t){return this.#e("addPageAction",e,t)}setPageViewName(e,t){return this.#e("setPageViewName",e,t)}setCustomAttribute(e,t,r){return this.#e("setCustomAttribute",e,t,r)}noticeError(e,t){return this.#e("noticeError",e,t)}setUserId(e){return this.#e("setUserId",e)}setApplicationVersion(e){return this.#e("setApplicationVersion",e)}setErrorHandler(e){return this.#e("setErrorHandler",e)}finished(e){return this.#e("finished",e)}addRelease(e,t){return this.#e("addRelease",e,t)}start(e){return this.#e("start",e)}recordReplay(){return this.#e(t.G4.RECORD)}pauseReplay(){return this.#e(t.G4.PAUSE)}addToTrace(e){return this.#e("addToTrace",e)}setCurrentRouteName(e){return this.#e("setCurrentRouteName",e)}interaction(){return this.#e("interaction")}log(e,t){return this.#e("logInfo",e,t)}wrapLogger(e,t,r){return this.#e("wrapLogger",e,t,r)}}var a=i(860),s=i(2983);const c=Object.values(a.K);function u(e){const t={};return c.forEach((r=>{t[r]=function(e,t){return!0===(0,s.gD)(t,"".concat(e,".enabled"))}(r,e)})),t}var l=i(2266);var d=i(1687),f=i(4234),g=i(5289),p=i(6154);const h=e=>p.RI&&!0===(0,s.gD)(e,"privacy.cookies_enabled");function v(e){return!!s.hR.MO&&h(e)&&!0===(0,s.gD)(e,"session_trace.enabled")}var m=i(6389);class b extends f.W{constructor(e,t,r){let n=!(arguments.length>3&&void 0!==arguments[3])||arguments[3];super(e,t,r),this.auto=n,this.abortHandler=void 0,this.featAggregate=void 0,this.onAggregateImported=void 0,!1===(0,s.gD)(this.agentIdentifier,"".concat(this.featureName,".autoStart"))&&(this.auto=!1),this.auto?(0,d.Ak)(e,r):this.ee.on("manual-start-all",(0,m.J)((()=>{(0,d.Ak)(this.agentIdentifier,this.featureName),this.auto=!0,this.importAggregator()})))}importAggregator(){let t,r=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};if(this.featAggregate||!this.auto)return;this.onAggregateImported=new Promise((e=>{t=e}));const n=async()=>{let n;try{if(h(this.agentIdentifier)){const{setupAgentSession:e}=await i.e(296).then(i.bind(i,2987));n=e(this.agentIdentifier)}}catch(t){(0,e.R)(20,t),this.ee.emit("internal-error",[t]),this.featureName===a.K.sessionReplay&&this.abortHandler?.()}try{if(!this.#t(this.featureName,n))return(0,d.Ze)(this.agentIdentifier,this.featureName),void t(!1);const{lazyFeatureLoader:e}=await i.e(296).then(i.bind(i,6103)),{Aggregate:o}=await e(this.featureName,"aggregate");this.featAggregate=new o(this.agentIdentifier,this.aggregator,r),t(!0)}catch(r){(0,e.R)(34,r),this.abortHandler?.(),(0,d.Ze)(this.agentIdentifier,this.featureName,!0),t(!1),this.ee&&this.ee.abort()}};p.RI?(0,g.GG)((()=>n()),!0):n()}#t(e,t){switch(e){case a.K.sessionReplay:return v(this.agentIdentifier)&&!!t;case a.K.sessionTrace:return!!t;default:return!0}}}var y=i(6630);class w extends b{static featureName=y.T;constructor(e,t){let r=!(arguments.length>2&&void 0!==arguments[2])||arguments[2];super(e,t,y.T,r),this.importAggregator()}}var A=i(4777),R=i(1478);class x extends A.J{constructor(e){super(e),this.aggregatedData={}}store(e,t,r,n,i){var o=this.getBucket(e,t,r,i);return o.metrics=function(e,t){t||(t={count:0});return t.count+=1,(0,R.$)(e,(function(e,r){t[e]=E(r,t[e])})),t}(n,o.metrics),o}merge(e,t,r,n,i){var o=this.getBucket(e,t,n,i);if(o.metrics){var a=o.metrics;a.count+=r.count,(0,R.$)(r,(function(e,t){if("count"!==e){var n=a[e],i=r[e];i&&!i.c?a[e]=E(i.t,n):a[e]=function(e,t){if(!t)return e;t.c||(t=_(t.t));return t.min=Math.min(e.min,t.min),t.max=Math.max(e.max,t.max),t.t+=e.t,t.sos+=e.sos,t.c+=e.c,t}(i,a[e])}}))}else o.metrics=r}storeMetric(e,t,r,n){var i=this.getBucket(e,t,r);return i.stats=E(n,i.stats),i}getBucket(e,t,r,n){this.aggregatedData[e]||(this.aggregatedData[e]={});var i=this.aggregatedData[e][t];return i||(i=this.aggregatedData[e][t]={params:r||{}},n&&(i.custom=n)),i}get(e,t){return t?this.aggregatedData[e]&&this.aggregatedData[e][t]:this.aggregatedData[e]}take(e){for(var t={},r="",n=!1,i=0;i<e.length;i++)t[r=e[i]]=Object.values(this.aggregatedData[r]||{}),t[r].length&&(n=!0),delete this.aggregatedData[r];return n?t:null}}function E(e,t){return null==e?function(e){e?e.c++:e={c:1};return e}(t):t?(t.c||(t=_(t.t)),t.c+=1,t.t+=e,t.sos+=e*e,e>t.max&&(t.max=e),e<t.min&&(t.min=e),t):{t:e}}function _(e){return{t:e,min:e,max:e,sos:e*e,c:1}}var N=i(384);var T=i(9908),k=i(2843),S=i(3878),I=i(782),j=i(1863);class O extends b{static featureName=I.T;constructor(e,t){let r=!(arguments.length>2&&void 0!==arguments[2])||arguments[2];super(e,t,I.T,r),p.RI&&((0,k.u)((()=>(0,T.p)("docHidden",[(0,j.t)()],void 0,I.T,this.ee)),!0),(0,S.sp)("pagehide",(()=>(0,T.p)("winPagehide",[(0,j.t)()],void 0,I.T,this.ee))),this.importAggregator())}}var P=i(3969);class D extends b{static featureName=P.TZ;constructor(e,t){let r=!(arguments.length>2&&void 0!==arguments[2])||arguments[2];super(e,t,P.TZ,r),this.importAggregator()}}new class extends o{constructor(t,r){super(r),p.gm?(this.sharedAggregator=new x({agentIdentifier:this.agentIdentifier}),this.features={},(0,N.bQ)(this.agentIdentifier,this),this.desiredFeatures=new Set(t.features||[]),this.desiredFeatures.add(w),this.runSoftNavOverSpa=[...this.desiredFeatures].some((e=>e.featureName===a.K.softNav)),(0,l.j)(this,t,t.loaderType||"agent"),this.run()):(0,e.R)(21)}get config(){return{info:this.info,init:this.init,loader_config:this.loader_config,runtime:this.runtime}}run(){try{const t=u(this.agentIdentifier),r=[...this.desiredFeatures];r.sort(((e,t)=>a.P[e.featureName]-a.P[t.featureName])),r.forEach((r=>{if(!t[r.featureName]&&r.featureName!==a.K.pageViewEvent)return;if(this.runSoftNavOverSpa&&r.featureName===a.K.spa)return;if(!this.runSoftNavOverSpa&&r.featureName===a.K.softNav)return;(function(e){switch(e){case a.K.ajax:return[a.K.jserrors];case a.K.sessionTrace:return[a.K.ajax,a.K.pageViewEvent];case a.K.sessionReplay:return[a.K.sessionTrace];case a.K.pageViewTiming:return[a.K.pageViewEvent];default:return[]}})(r.featureName).every((e=>e in this.features))||(0,e.R)(36,r.featureName),this.features[r.featureName]=new r(this.agentIdentifier,this.sharedAggregator)}))}catch(t){(0,e.R)(22,t);for(const e in this.features)this.features[e].abortHandler?.();const r=(0,N.Zm)();delete r.initializedAgents[this.agentIdentifier]?.api,delete r.initializedAgents[this.agentIdentifier]?.features,delete this.sharedAggregator;return r.ee.get(this.agentIdentifier).abort(),!1}}}({features:[w,O,D],loaderType:"lite"})})()})();</script>
    <meta name="keywords" content="Dominos side order, Dominos India, Pizza India" />
    <meta name="description" content="Dominos Side Orders - Breads, Pastas, Dips, Deserts, chicken delights and more. Order Pizza Online for take away or Free Home Delivery." />
          <h1 class="visible-hidden hide" style="display:none;"> Dominos side order, Dominos India, Pizza India    </h1>
          <meta property="og:image" content="https://www.dominos.co.in/theme2/front/images/home/Dominos-APP-LOGO-1.png" />
    <meta property="og:url" content="https://www.dominos.co.in/" />
    <meta property="og:type" content="website" />
    <meta property="og:description" content="Order Domino's Pizza Online and get deliveries in 30 Minutes*. Select your favorite Veg/Non-Veg Pizzas and get the best deals/coupons online. Everyday Value Offer - 2 regular pizzas @ ₹99 each | 2 medium pizzas @ ₹199 each." />
    <link rel="stylesheet" href="https://www.dominos.co.in/theme2/front/css/bootstrap.min.css" media="all"/>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="preload" as="style" onload="this.rel='stylesheet'" >
    <link href="https://www.dominos.co.in/theme2/front/images/mobile-images/mbl-logo.png" rel="shortcut icon"/>
    <link rel="stylesheet" href="https://www.dominos.co.in/theme2/front/css/inputEffects.css" media="all"/>
    <link rel="stylesheet" href="https://www.dominos.co.in/theme2/front/css/style.min.css?ver=5" media="all"/>
    <link  rel="dns-prefetch" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script defer src="https://www.dominos.co.in/theme2/front/js/header.min.js"></script> 
    <link rel="stylesheet" href="../styles/style1.css">
    <link rel="stylesheet" href="../../styles/style1.css">
   
    <script  src="https://www.dominos.co.in/theme2/front/js/jquery.min.js"></script>
    <script defer src="https://www.dominos.co.in/theme2/front/js/jquery-ui.min.js"></script>
    <script defer src="https://www.dominos.co.in/theme2/front/js/bootstrap.min.js"></script>
    <script defer src="https://www.dominos.co.in/theme2/front/js/classie.min.js"></script>  
    <script defer src="https://www.dominos.co.in/theme2/front/js/common.js?ver=1"></script>
        <!--<script src="https://www.dominos.co.in/theme2/front/js/payment-option.js"></script>-->
    <!--<script src="https://www.dominos.co.in/theme2/front/js/advertisement.js"></script>-->
    <!--<script src="https://www.dominos.co.in/theme2/front/js/evoucher.js"></script>-->
                    <!--[if lt IE 7 ]>
       <html lang="en" dir="ltr" class="ie ie6">
       <![endif]-->
        <!--[if IE 7 ]>
        <html lang="en" dir="ltr" class="ie ie7">
        <![endif]-->
        <!--[if IE 8 ]>
        <html lang="en" dir="ltr" class="ie ie8">
        <![endif]-->
        <!--[if IE 9 ]>
        <html lang="en" dir="ltr" class="ie ie9">
        <![endif]-->
        <!--[if gt IE 9]>
        <html lang="en" dir="ltr" class="ie">
        <![endif]-->
        <!--[if !IE]>
        <html lang="en" dir="ltr">
           <![endif]-->
                    
        <script type='text/javascript'>
           var _vwo_clicks=10;
        </script>
        <!-- Start Visual Website Optimizer Asynchronous Code -->
        <script type='text/javascript'>
        var _vwo_code=(function(){
        var account_id=197927,
        settings_tolerance=2000,
        library_tolerance=2500,
        use_existing_jquery=false,
        /* DO NOT EDIT BELOW THIS LINE */
        f=false,d=document;return{use_existing_jquery:function(){
        return use_existing_jquery;}, library_tolerance:function(){
        return library_tolerance;},finish:function(){
        if(!f){f=true;var a=d.getElementById('_vis_opt_path_hides');
        if(a)a.parentNode.removeChild(a);}},finished:function(){return f;},
        load:function(a){var b=d.createElement('script');b.src=a;
        b.type='text/javascript';b.innerText;b.onerror=function()
        {_vwo_code.finish();};d.getElementsByTagName('head')[0].appendChild(b);},
        init:function(){settings_timer=setTimeout('_vwo_code.finish()',
        settings_tolerance);var a=d.createElement('style'),
        b='body{opacity:0 !important;filter:alpha(opacity=0) !important;background:none !important;}',
        h=d.getElementsByTagName('head')[0];a.setAttribute('id','_vis_opt_path_hides');
        a.setAttribute('type','text/css');if(a.styleSheet)a.styleSheet.cssText=b;
        else a.appendChild(d.createTextNode(b));h.appendChild(a);
        this.load('//dev.visualwebsiteoptimizer.com/j.php?a='+account_id+'&u='+encodeURIComponent(d.URL)+'&r='+Math.random());
        return settings_timer;}};}());_vwo_settings_timer=_vwo_code.init();
        </script>
<!-- End Visual Website Optimizer Asynchronous Code -->

 <!-- Start Google Tag Manager -->
        <link rel="preconnect" href="https://www.googletagmanager.com">
<link rel="preconnect" href="https://www.google-analytics.com">
        <script async src="https://www.googletagmanager.com/gtag/js?id=GTM-MW6ZCB"></script>
<script type="application/javascript">
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'GTM-MW6ZCB');
</script>
        <!-- End Google Tag Manager -->
        
        <!-- Begin: Organization Tag-->
        <script type="application/ld+json">
	        {
	        	"@context" : "https://schema.org",
	            "@type" : "Organization",
	            "Name" : "Domino's India",
	            "URL" : "https://www.dominos.co.in",
	            "contactPoint" : [{
	            	"@type" : "ContactPoint",
	            	"telephone" : "1800-208-1234",
	            	"contactType" : "Customer Service"
                        	            }],
	            "logo" : "https://www.dominos.co.in/theme2/front/images/home/Dominos-APP-LOGO-1.png",
	            "sameAs" : [
	            	"https://www.facebook.com/dominospizzaindia/",
	            	"https://twitter.com/dominos_india",
	            	"https://www.instagram.com/dominos_india/",
	            	"https://www.youtube.com/user/dominosindia"
	            ]
	        }
	    </script>
        <!-- End: Organization Tag-->
        
        <!--Begin: Versa Tag-->
        <script>
          var versaTag = {};
          versaTag.id = "1839";
          versaTag.sync = 0;
          versaTag.dispType = "js";
          versaTag.ptcl = "HTTPS";
          versaTag.bsUrl = "bs.serving-sys.com/BurstingPipe";
          versaTag.activityParams = {
          };
          versaTag.retargetParams = {};
          versaTag.dynamicRetargetParams = {};
          versaTag.conditionalParams = {};
        </script>
        <script id="ebOneTagUrlId" src="https://secure-ds.serving-sys.com/SemiCachedScripts/ebOneTag.js"></script>
        <noscript>
          <iframe src="https://bs.serving-sys.com/BurstingPipe?
                  cn=ot&amp;
                  onetagid=1839&amp;
                  ns=1&amp;
                  activityValues=$$
                  Value=[Value]&amp;
                  OrderID=[OrderID]&amp;
                  ProductID=[ProductID]&amp;
                  ProductInfo=[ProductInfo]&amp;
                  Quantity=[Quantity]&amp;$$&amp;
                  retargetingValues=$$&amp;
                  dynamicRetargetingValues=$$&amp;
                  acp=$$$$&amp;"
                  style="display:none;width:0px;height:0px"></iframe>
        </noscript>
        <!-- End: Versa Tag--> 
        
  </head>
  <body>
    <div class="main-wrapper col-xs-12">
      <div class="col-xs-12 pd-N">
        <style>
body{
  font-size: 14px;
  line-height: 1.42857143;
}
@media screen and (max-width: 992px){
  #header{
position:fixed;
top:0px;
  }
}
</style>
<header  class="pg-header col-xs-12 pd-N" id="header">
  <div class="col-xs-12 pd-N">
    <div class="container-fluid mob-nav-menu pd-LR">
      <div class="col-xs-12 pd-LR" id="pg-menu">
      <div class="container pd-LR">
          <div class="col-md-3 hidden-xs pull-right home-order-online pd-N">
              <div class="order-online">
                  <div class="col-md-6 pull-left download-app-btn">
                      <a href="https://play.google.com/store/apps/details?id=com.Dominos&hl=en">
                          <span class="online-text">Download the app</span>
                      </a>
                  </div>
                  <div class="col-md-6 pull-right order-online-btn">
                      <a href="https://pizzaonline.dominos.co.in/?src=brand">
                          <span class="online-text">Order online now</span>
                          <!--<span class="arrow-right"></span>-->
                      </a>
                  </div>
              </div>
          </div>
        <div class="col-md-2 col-xs-4 col-sm-2 logo pd-LR">
          <div class="visible-xs menu-btn" onclick="openNav()"><span>&nbsp;</span><span>&nbsp;</span><span>&nbsp;</span></div>
          <a class="hidden-xs" href="https://www.dominos.co.in/home" title="Domino's"><img class="img-responsive" src="https://www.dominos.co.in/theme2/front/images/dominos-logo-241x53.png" height="31" width="140" alt="Domino's Logo" title="Domino's"/></a>
          <a class="visible-xs" href="https://www.dominos.co.in/home" title="Domino's"><img class="img-responsive" src="https://www.dominos.co.in/theme2/front/images/mobile-images/mbl-logo.png" height="40" width="40" alt="Domino's Logo" title="Domino's"/></a>
        </div>
        <style>
@media screen and (max-width: 992px){

#header ul li a, .vertical-box div p:last-child {
    font-size: 12px!important;
    text-decoration: none;
}
}
</style>
        <div class="col-md-7 col-sm-10 col-xs-8 pull-right menu-scroll pd-LR">
          <ul class="nav nav-tabs list-header" role="tablist">
                        <li class=""><a style="font-family:Oswald-Regular;font-display:swap;" href="https://www.dominos.co.in/menu" class="menu-tree"
                                                 title="Our Menu"role="tab" 
                                                 target=""  >Our menu</a><span></span></li>
                       <li class=""><a style="font-family:Oswald-Regular;font-display:swap;" href="https://www.dominos.co.in/store-locations/" class=""
                                                 title="STORE"role="" 
                                                 target="_blank"  >Domino's Stores</a><span></span></li>
                       <li class=""><a style="font-family:Oswald-Regular;font-display:swap;" href="https://www.dominos.co.in/gift-vouchers" class="hidden-xs"
                                                 title="GIFT CARD"role="" 
                                                 target=""  >Gift Card</a><span></span></li>
                       <li class=""><a style="font-family:Oswald-Regular;font-display:swap;" href="https://www.dominos.co.in/virtual-pizza-party" class="hidden-xs"
                                                 title="CORPORATE ENQUIRY"role="" 
                                                 target=""  >Corporate enquiry</a><span></span></li>
                       <li class=""><a style="font-family:Oswald-Regular;font-display:swap;" href="https://www.dominos.co.in/contact" class="hidden-xs hidden-sm"
                                                 title="contact"role="" 
                                                 target=""  >Contact</a><span></span></li>
                     </ul>
        </div>
          
          
          </div>
          <div id="shadow-box" onclick="closeNav()"></div>
        <div class="visible-xs col-xs-12 pd-LR" id="side-menu">
          <ul class="nav navbar-nav" role="tablist">
                          <li class=""><a href="https://www.dominos.co.in/home" class="visible-xs" title="Home"
                                                   role="tab"target=""> 
                      <!--<img class="mR" src="" alt="" title="">-->
                      <span>Home</span></a><span></span></li>
                         <li class=""><a href="https://www.dominos.co.in/menu" class="menu-tree" title="Our Menu"
                                                                             role="tab"target=""> <span>Our menu</span></a><span></span></li>
                           <li class=""><a href="https://www.dominos.co.in/gift-vouchers" class="" title="GIFT CARD"
                                                                             role=""target=""> <span>Gift Card</span></a><span></span></li>
                           <li class=""><a href="https://www.dominos.co.in/store-locations/" class="" title="STORE"
                                                   role=""target="_blank"> 
                      <!--<img class="mR" src="" alt="" title="">-->
                      <span>Restaurants Near Me</span></a><span></span></li>
                         <li class=""><a href="https://www.dominos.co.in/bday-party" class="" title="BIRTHDAY"
                                                                             role=""target=""> <span>Birthday Parties</span></a><span></span></li>
                           <li class=""><a href="https://www.dominos.co.in/wedding" class="" title="CATERING"
                                                                             role=""target=""> <span>Corporate Orders</span></a><span></span></li>
                           <li class=""><a href="https://www.dominos.co.in/blog" class="" title="BLOG"
                                                   role=""target="_blank"> 
                      <!--<img class="mR" src="" alt="" title="">-->
                      <span>Blog</span></a><span></span></li>
                         <li class=""><a href="http://www.jubilantfoodworks.com/investors/" class="" title="INVESTORS"
                                                                             role=""target="_blank"> <span>Investors</span></a><span></span></li>
                           <li class=""><a href="https://www.dominos.co.in/feedback" class="" title="FEEDBACK"
                                                   role=""target=""> 
                      <!--<img class="mR" src="" alt="" title="">-->
                      <span>Feedback</span></a><span></span></li>
                         <li class=""><a href="https://www.dominos.co.in/contact" class="" title="contact"
                                                                             role=""target=""> <span>Contact Us</span></a><span></span></li>
                           <li class=""><a href="https://www.dominos.co.in/advertisement" class="" title="ADS"
                                                                             role=""target=""> <span>Ads</span></a><span></span></li>
                       </ul>
        </div>
      </div>
            </div>
  </div>
</header>
<style>
@media screen and (max-width: 992px){
.breadcrumb-nm {
    font-size: 12px!important;
}
.breadcrumb{
  float:left;
  width:100%;
  margin-top:60px;
}

}
</style>
              <ul class="breadcrumb" vocab="https://schema.org/" typeof="BreadcrumbList">
                                            <li property="itemListElement" typeof="ListItem"><a property="item" typeof="WebPage" href="https://www.dominos.co.in"><span class="breadcrumb-nm" property="name">Home</span></a><meta property="position" content="1"></li>
                                <li property="itemListElement" typeof="ListItem"><a property="item" typeof="WebPage" href="https://www.dominos.co.in/404"><span class="breadcrumb-nm" property="name">404</span></a><meta property="position" content="2"></li>
                              </ul>
 
<script type="text/javascript" src='https://www.dominos.co.in/theme2/front/js/header.min.js'></script>
 <!--<script src='https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit" async defer'></script> -->

      </div>
      <div class="content-wrapper col-xs-12" id="content-box">
        <section class="main-content clearfix">
    <!--<div class=" pg-title-box text-center">    
      <p class=" thanks-box pg-subtitle"><b>
            <h2 style="color: #FF0000">Page not found</h2>
        </b>
      </p>
    </div>-->
    <div class="row text-center" data-hook="" id="wrapper">
    <div class="page-head-alt">
      <h1 class="text-jumbo text-ginormous hide-sm">Oops!</h1>
    </div>

    <dl>
      <h2>We can't seem to find the page you're looking for.</h2>
      <h6>Error code: 404</h6>
    </dl>

    <dl>
      <dt>Here are some helpful links instead:</dt>

      <dd>
        <ul class="disc">
          <li>
            <a class="head_color" style="color:blue;" href="https://www.dominos.co.in" >Home</a>
          </li>

          <li>
            <a class="head_color" style="color:blue;" href="https://www.dominos.co.in/store-locations/" >Domino's Stores</a>
          </li>
          <li>
            <a class="head_color" style="color:blue;" href="https://www.dominos.co.in/contact" >Contact</a>
          </li>
        </ul>
      </dd>
    </dl>
  </div>
</section>
<link rel="stylesheet" href="../../styles/style1.css">      </div>
        <div class="tab-content col-xs-12 pd-N" style="margin-bottom:20px;">
    <div class="st-box-white mobile-footer">
    <a class="card-link st-block collapsed accordion-toggle" data-toggle="collapse" href="#container-store" aria-expanded="false">
      <h2 class="footer-name">Top Restaurants</h2>                           
      <span class="pull-right" style="margin-top:-38px;color:black;margin-right:6px;">
      <i class="fa fa-chevron-down" aria-hidden="true">
      </i>
      </span>
    </a>
  <div class="container-link st-accordion collapse " data-parent="#faq-accordion" id="container-store">
  <span class="link-item test-label label-default"><a href="https://www.dominos.co.in/store-locations/chennai" target="_blank">Restaurants in Chennai</a></span>
  <span class="link-item test-label label-default"><a href="https://www.dominos.co.in/store-locations/hyderabad" target="_blank">Restaurants in Hyderabad</a></span>
  <span class="link-item test-label label-default"><a href="https://www.dominos.co.in/store-locations/bangalore" target="_blank">Restaurants in Bangalore</a></span>
  <span class="link-item test-label label-default"><a href="https://www.dominos.co.in/store-locations/kolkata" target="_blank">Restaurants in Kolkata</a></span>
  <span class="link-item test-label label-default"><a href="https://www.dominos.co.in/store-locations/mumbai" target="_blank">Restaurants in Mumbai</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/store-locations/new-delhi" target="_blank">Restaurants in New Delhi</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/store-locations/ahmedabad" target="_blank">Restaurants in Ahmedabad</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/store-locations/pune" target="_blank">Restaurants in Pune</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/store-locations/goa" target="_blank">Restaurants in Goa</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/store-locations/jaipur" target="_blank">Restaurants in Jaipur</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/store-locations/chandigarh" target="_blank">Restaurants in Chandigarh</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/store-locations/lucknow" target="_blank">Restaurants in Lucknow</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/store-locations/mysore" target="_blank">Restaurants in Mysore</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/store-locations/patna" target="_blank">Restaurants in Patna</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/store-locations/guwahati" target="_blank">Restaurants in Guwahati</a></span>
</div>
</div>
</div>
<div class="tab-content col-xs-12 pd-N" style="margin-bottom:30px;">
    <div class="st-box-white mobile-footer">
    <a class="card-link st-block collapsed accordion-toggle" data-toggle="collapse" href="#container-footer" aria-expanded="false">
      <h2 class="footer-name">Menu</h2>                           
      <span class="pull-right" style="margin-top:-38px;color:black;margin-right:6px;">
      <i class="fa fa-chevron-down" aria-hidden="true">
      </i>
      </span>
    </a>
<div class="container-link st-accordion collapse" id="container-footer">
  <span class="link-item test-label label-default"><a href="https://www.dominos.co.in/menu" target="_blank">Menu</a></span>
  <span class="link-item test-label label-default"><a href="https://www.dominos.co.in/menu/veg-pizzas" target="_blank">Veg Pizza</a></span>
  <span class="link-item test-label label-default"><a href="https://www.dominos.co.in/menu/non-veg-pizzas" target="_blank">Chicken Pizza</a></span>
  <span class="link-item test-label label-default"><a href="https://www.dominos.co.in/menu/pasta" target="_blank">Pasta</a></span>
  <span class="link-item test-label label-default"><a href="https://www.dominos.co.in/menu/choice-of-crusts" target="_blank">Pizza Crust</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/beverages" target="_blank">Beverages</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/pizza-mania" target="_blank">Pizza Mania</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/burger-pizza" target="_blank">Burger Pizza</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/veg-pizzas/farm-house" target="_blank">Farm House pizza</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/veg-pizzas/margherita" target="_blank">Veg Margherita Pizza</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/veg-pizzas/cheese-n-corn" target="_blank">Cheese Corn Pizza</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/veg-pizzas/double-cheese-margherita" target="_blank">Double Cheese Margherita Pizza</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/veg-pizzas/paneer-makhani" target="_blank">Paneer Makhani Pizza</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/side-orders/lava-cake" target="_blank">Choco Lava Cake</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/chicken/roasted-chicken-wings-peri-peri" target="_blank">Roasted Chicken Wings Peri Peri</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/side-orders/garlic-breadsticks" target="_blank">Garlic Bread</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/side-orders/stuffed-garlic-bread" target="_blank">Stuffed Garlic Bread</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/side-orders/veg-parcel" target="_blank">Paneer Zingy Parcel</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/choice-of-crusts/fresh-pan-pizza" target="_blank">Fresh Pan Pizza</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/choice-of-crusts/new-hand-tossed" target="_blank">New Hand Tossed Pizza</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/choice-of-crusts/classic-hand-tossed" target="_blank">Classic Hand Tossed Pizza</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/pizza-mania/golden-corn" target="_blank">Golden Corn Pizza</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/menu/choice-of-toppings/extra-cheese" target="_blank">Extra Cheese Pizza</a></span>
  <span class="link-item shuffle test-label label-default"><a href="https://www.dominos.co.in/great-deals/online-pizza-coupons/dominos-wednesday-offers" target="_blank">Wednesday Offer - Pizza Buy 1 Get 1</a></span>
  </div>
  </div>
       <style>
@media (max-width: 720px)
.link-item>a {
    color: #131415;
}
.container-link{
  padding-right: 0.2em;
  padding-left: 0.2em;
}
.test-label{
 margin-right: 0.3em;
}
}
.test-label{
display: inline;
    padding: 0.2em 0.6em 0.3em;
    font-size: 75%;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    vertical-align: baseline;
    border-radius: 0.25em;
}
.img{
  aspect-ratio : 16/9
}
</style>

<div class="footer-wrapper">
    <div class="footer-desktop">
      <ul class="footer-links">
        <a href="https://www.dominos.co.in/menu"><li class="list-header">Menu</li></a>
        <li><a href="https://www.dominos.co.in/menu/veg-pizzas">Veg Pizza</a></li>
        <li><a href="https://www.dominos.co.in/menu/non-veg-pizzas">Chicken Pizza</a></li>
        <li><a href="https://www.dominos.co.in/menu/pasta">Pasta</a></li>
        <li><a href="https://www.dominos.co.in/menu/choice-of-crusts">Pizza Crust</a></li>
        <li><a href="https://www.dominos.co.in/menu/beverages">Beverages</a></li>
        <li><a href="https://www.dominos.co.in/menu/pizza-mania">Pizza Mania</a></li>
        <li><a href="https://www.dominos.co.in/menu/burger-pizza">Burger Pizza </a></li>
      </ul>
      <ul class="footer-links">
        <li class="list-header">COMPANY</li>
        <li><a href="/blog">Blog</a></li>
        <li><a href="http://www.jubilantfoodworks.com/investors/">Investor</a></li>
        <li><a href="/feedback">FeedBack</a></li>
        <li><a href="/advertisement">Ads</a></li>
      </ul>
      <ul class="footer-links">
        <li class="list-header">PIZZA RESTAURANTS</li>
        <li><a href="https://www.dominos.co.in/restaurants-near-me">Restaurants Near Me</a></li>
        <li><a href="https://www.dominos.co.in/pizza-near-me">Pizza Near Me</a></li>
        <li><a href="https://www.dominos.co.in/food-near-me">Food Near Me</a></li>
        <li><a href="https://www.dominos.co.in/food-delivery">Food Delivery</a></li>
        <li><a href="https://www.dominos.co.in/italian-food">Italian Food</a></li>
        <li><a href="https://www.dominos.co.in/order-food-online">Order Food Online</a></li>
      </ul>
      <ul class="footer-links">
        <li class="list-header">ABOUT</li>
        <li><a href="/gift-vouchers">Gift card</a></li>
        <li><a href="https://pizzaonline.dominos.co.in/cardBalance">Card Balance Enquiry</a></li>
        <li><a href="https://pizzaonline.dominos.co.in/faq">FAQ</a></li>
        <li><a href="https://www.dominos.co.in/virtual-pizza-party">Virtual Pizza Party</a></li>
        <li><a href="https://www.dominos.co.in/e-gift-voucher">E-Gift Vouchers</a></li>
      </ul>
      <ul class="footer-links">
        <li class="list-header">LEGAL</li>
        <li><a href="https://pizzaonline.dominos.co.in/disclaimer">Disclaimer</a></li>
        <li><a href="https://pizzaonline.dominos.co.in/tnc">Terms & Conditions</a></li> 
        <li><a href="/privacy-policy">Privacy Policy</a></li>
      </ul>
      <ul class="footer-links">
        <li class="list-header">SOCIAL MEDIA</li>
        <li>
          <ul class="social-links">
            <li>
              <a href="https://www.facebook.com/dominospizzaindia" target="_blank">
                <img 
                  srcset="https://www.dominos.co.in/assets/fb.png 1x, https://www.dominos.co.in/assets/fb@2x.png 2x, https://www.dominos.co.in/assets/fb@3x.png 3x" src="https://www.dominos.co.in/assets/fb.png"
                  alt="facebook"
                >
              </a>
            </li>
            <li>
              <a href="https://twitter.com/dominos_india" target="_blank">
                <img 
                  srcset="https://www.dominos.co.in/assets/twitter.png 1x, https://www.dominos.co.in/assets/twitter@2x.png 2x, https://www.dominos.co.in/assets/twitter@3x.png 3x" src="https://www.dominos.co.in/assets/twitter.png"
                  alt="Twitter"
                >
              </a>
            </li>
            <li>
              <a href="https://www.instagram.com/dominos_india/?hl=en" target="_blank">
                <img 
                  srcset="https://www.dominos.co.in/assets/instagram@3x.png 3x, https://www.dominos.co.in/assets/instagram.png 1x, https://www.dominos.co.in/assets/instagram@2x.png 2x" src="https://www.dominos.co.in/assets/instagram.png"
                  alt="Instagram"
                >
              </a>
          </li>
          <li>
            <a href="https://www.youtube.com/user/dominosindia" target="_blank">
              <img 
                srcset="https://www.dominos.co.in/assets/You_tube.png 1x, https://www.dominos.co.in/assets/You_tube@2x.png 2x, https://www.dominos.co.in/assets/You_tube@3x.png 3x" src="https://www.dominos.co.in/assets/You_tube.png"
                alt="You_tube"
              >
            </a>
          </li>
        </ul>
        </li>
        <li>
          <a href="tel:18002081234">
            <img 
              srcset="https://www.dominos.co.in/assets/hello_dominos_20210615.png 1x, https://www.dominos.co.in/assets/hello_dominos_20210615@2x.png 2x, https://www.dominos.co.in/assets/hello_dominos_20210615@3x.png 3x" src="https://www.dominos.co.in/assets/hello_dominos_20210615.png"
              alt="Domino's Customer Care Number" 
            >
          </a>
        </li>
      </ul>
    </div>
    <ul class="footer-links footer-mobile">
    <ul class="footer-mb">
        <li class="list-header">PIZZA RESTAURANTS</li>
        <li><a href="https://www.dominos.co.in/restaurants-near-me">Restaurants Near Me</a></li>
        <li><a href="https://www.dominos.co.in/pizza-near-me">Pizza Near Me</a></li>
        <li><a href="https://www.dominos.co.in/food-near-me">Food Near Me</a></li>
        <li><a href="https://www.dominos.co.in/food-delivery">Food Delivery</a></li>
        <li><a href="https://www.dominos.co.in/italian-food">Italian Food</a></li>
        <li><a href="https://www.dominos.co.in/order-food-online">Order Food Online</a></li>
      </ul>
    <ul class="footer-mb">
        <a href="https://www.dominos.co.in/menu"><li class="list-header">Menu</li></a>
        <li><a href="https://www.dominos.co.in/menu/veg-pizzas">Veg Pizza</a></li>
        <li><a href="https://www.dominos.co.in/menu/non-veg-pizzas">Chicken Pizza</a></li>
        <li><a href="https://www.dominos.co.in/menu/pasta">Pasta</a></li>
        <li><a href="https://www.dominos.co.in/menu/choice-of-crusts">Pizza Crust</a></li>
        <li><a href="https://www.dominos.co.in/menu/beverages">Beverages</a></li>
        <li><a href="https://www.dominos.co.in/menu/pizza-mania">Pizza Mania</a></li>
        <li><a href="https://www.dominos.co.in/menu/burger-pizza">Burger Pizza </a></li>
      </ul>
      <ul class="footer-mb">
        <li class="list-header">COMPANY</li>
        <li><a href="/blog">Blog</a></li>
        <li><a href="http://www.jubilantfoodworks.com/investors/">Investor</a></li>
        <li><a href="/feedback">FeedBack</a></li>
        <li><a href="/advertisement">Ads</a></li>
      </ul>
      <ul class="footer-mb">
        <li class="list-header">ABOUT</li>
        <li><a href="/gift-vouchers">Gift card</a></li>
        <li><a href="https://pizzaonline.dominos.co.in/cardBalance">Card Balance Enquiry</a></li>
        <li><a href="https://pizzaonline.dominos.co.in/faq">FAQ</a></li>
        <li><a href="https://www.dominos.co.in/virtual-pizza-party">Virtual Pizza Party</a></li>
        <li><a href="https://www.dominos.co.in/e-gift-voucher">E-Gift Vouchers</a></li>
      </ul>
      <ul class="footer-mb">
        <li class="list-header">LEGAL</li>
        <li><a href="https://pizzaonline.dominos.co.in/disclaimer">Disclaimer</a></li>
        <li><a href="https://pizzaonline.dominos.co.in/tnc">Terms & Conditions</a></li> 
        <li><a href="/privacy-policy">Privacy Policy</a></li>
      </ul>
    </ul>
    <ul class="help-links">
      <li>
        <ul class="share-links">
          <li>
            <a href="https://www.facebook.com/dominospizzaindia" target="_blank">
              <img width="28" height="29"
                srcset="https://www.dominos.co.in/assets/fb.png 1x, https://www.dominos.co.in/assets/fb@2x.png 2x, https://www.dominos.co.in/assets/fb@3x.png 3x" src="https://www.dominos.co.in/assets/fb.png"
                alt="facebook"
              >
            </a>
          </li>
          <li>
            <a href="https://twitter.com/dominos_india" target="_blank">
              <img width="26" height="33"
                srcset="https://www.dominos.co.in/assets/twitter.png 1x, https://www.dominos.co.in/assets/twitter@2x.png 2x, https://www.dominos.co.in/assets/twitter@3x.png 3x" src="https://www.dominos.co.in/assets/twitter.png"
                alt="Twitter"
              >
            </a>
          </li>
          <li>
            <a href="https://www.instagram.com/dominos_india/?hl=en" target="_blank">
              <img width="30" height="31"
                srcset="https://www.dominos.co.in/assets/instagram@3x.png 3x, https://www.dominos.co.in/assets/instagram.png 1x, https://www.dominos.co.in/assets/instagram@2x.png 2x" src="https://www.dominos.co.in/assets/instagram.png"
                alt="Instagram"
              >
            </a>
          </li>
          <li>
            <a href="https://www.youtube.com/user/dominosindia" target="_blank">
              <img width="31" height="39"
                srcset="https://www.dominos.co.in/assets/You_tube@3x.png 3x, https://www.dominos.co.in/assets/You_tube.png 1x, https://www.dominos.co.in/assets/You_tube@2x.png 2x" src="https://www.dominos.co.in/assets/You_tube.png"
                alt="You_tube"
              >
            </a>
            </li>
        </ul>
      </li>
      <li>
        <a href="tel:18002081234">
          <img width="150" height="40"
            srcset="https://www.dominos.co.in/assets/hello_dominos_20210615.png 1x, https://www.dominos.co.in/assets/hello_dominos_20210615@2x.png 2x, https://www.dominos.co.in/assets/hello_dominos_20210615@3x.png 3x" src="https://www.dominos.co.in/assets/hello_dominos_20210615.png"
            alt="Domino's Customer Care Number" 
          >
        </a>
      </li>
    </ul>
   <div class="copyright">
      All Rights Reserved. Copyright © Jubilant FoodWorks Ltd.
  </div>
</div>

<div class="col-xs-12 bottom-box">
    All rights reserved. Copyright © Jubilant FoodWorks Ltd. <a href="https://pizzaonline.dominos.co.in/disclaimer" title="Disclaimer">Disclaimer</a> | <a href="https://pizzaonline.dominos.co.in/tnc" title="T&C">T&C</a> | <a href="https://www.dominos.co.in/privacy-policy" title="Privacy Policy"> Privacy Policy</a>
</div>

<script>
$(document).ready(function(){
      let activities = [
['Restaurants in Abohar','https://www.dominos.co.in/store-locations/abohar'],
['Restaurants in Agra','https://www.dominos.co.in/store-locations/agra'],
['Restaurants in Ahmadnagar','https://www.dominos.co.in/store-locations/ahmadnagar'],
['Restaurants in Ajmer','https://www.dominos.co.in/store-locations/ajmer'],
['Restaurants in Akola','https://www.dominos.co.in/store-locations/akola'],
['Restaurants in Aligarh','https://www.dominos.co.in/store-locations/aligarh'],
['Restaurants in Allahabad','https://www.dominos.co.in/store-locations/allahabad'],
['Restaurants in Alwar','https://www.dominos.co.in/store-locations/alwar'],
['Restaurants in Ambala','https://www.dominos.co.in/store-locations/ambala'],
['Restaurants in Amravati','https://www.dominos.co.in/store-locations/amravati'],
['Restaurants in Amritsar','https://www.dominos.co.in/store-locations/amritsar'],
['Restaurants in Anand','https://www.dominos.co.in/store-locations/anand'],
['Restaurants in Ankleshwar','https://www.dominos.co.in/store-locations/ankleshwar'],
['Restaurants in Ara','https://www.dominos.co.in/store-locations/ara'],
['Restaurants in Asansol','https://www.dominos.co.in/store-locations/asansol'],
['Restaurants in Aurangabad','https://www.dominos.co.in/store-locations/aurangabad'],
['Restaurants in Baddi','https://www.dominos.co.in/store-locations/baddi'],
['Restaurants in Bahadurgarh','https://www.dominos.co.in/store-locations/bahadurgarh'],
['Restaurants in Bangalore','https://www.dominos.co.in/store-locations/bangalore'],
['Restaurants in Barabanki','https://www.dominos.co.in/store-locations/barabanki'],
['Restaurants in Baramati','https://www.dominos.co.in/store-locations/baramati'],
['Restaurants in Bardoli','https://www.dominos.co.in/store-locations/bardoli'],
['Restaurants in Bareilly','https://www.dominos.co.in/store-locations/bareilly'],
['Restaurants in Batala','https://www.dominos.co.in/store-locations/batala'],
['Restaurants in Begusarai','https://www.dominos.co.in/store-locations/begusarai'],
['Restaurants in Belgaum','https://www.dominos.co.in/store-locations/belgaum'],
['Restaurants in Bellari','https://www.dominos.co.in/store-locations/bellari'],
['Restaurants in Berhampur','https://www.dominos.co.in/store-locations/berhampur'],
['Restaurants in Bettiah','https://www.dominos.co.in/store-locations/bettiah'],
['Restaurants in Bhagalpur','https://www.dominos.co.in/store-locations/bhagalpur'],
['Restaurants in Bharuch','https://www.dominos.co.in/store-locations/bharuch'],
['Restaurants in Bhatinda','https://www.dominos.co.in/store-locations/bhatinda'],
['Restaurants in Bhavnagar','https://www.dominos.co.in/store-locations/bhavnagar'],
['Restaurants in Bhilai','https://www.dominos.co.in/store-locations/bhilai'],
['Restaurants in Bhilwara','https://www.dominos.co.in/store-locations/bhilwara'],
['Restaurants in Bhiwadi','https://www.dominos.co.in/store-locations/bhiwadi'],
['Restaurants in Bhiwani','https://www.dominos.co.in/store-locations/bhiwani'],
['Restaurants in Bhopal','https://www.dominos.co.in/store-locations/bhopal'],
['Restaurants in Bhubaneswar','https://www.dominos.co.in/store-locations/bhubaneswar'],
['Restaurants in Bhuj','https://www.dominos.co.in/store-locations/bhuj'],
['Restaurants in Bijapur','https://www.dominos.co.in/store-locations/bijapur'],
['Restaurants in Bijnor','https://www.dominos.co.in/store-locations/bijnor'],
['Restaurants in Bikaner','https://www.dominos.co.in/store-locations/bikaner'],
['Restaurants in Bilaspur','https://www.dominos.co.in/store-locations/bilaspur'],
['Restaurants in Boisar','https://www.dominos.co.in/store-locations/boisar'],
['Restaurants in Bokaro','https://www.dominos.co.in/store-locations/bokaro'],
['Restaurants in Burdwan','https://www.dominos.co.in/store-locations/burdwan'],
['Restaurants in Calicut','https://www.dominos.co.in/store-locations/calicut'],
['Restaurants in Chandrapur','https://www.dominos.co.in/store-locations/chandrapur'],
['Restaurants in Chhindwara','https://www.dominos.co.in/store-locations/chhindwara'],
['Restaurants in Chiplun','https://www.dominos.co.in/store-locations/chiplun'],
['Restaurants in Chittorgarh','https://www.dominos.co.in/store-locations/chittorgarh'],
['Restaurants in Cochin','https://www.dominos.co.in/store-locations/cochin'],
['Restaurants in Coimbatore','https://www.dominos.co.in/store-locations/coimbatore'],
['Restaurants in Cuttack','https://www.dominos.co.in/store-locations/cuttack'],
['Restaurants in Dadra And Nagar Haveli','https://www.dominos.co.in/store-locations/dadra-and-nagar-haveli'],
['Restaurants in Daman','https://www.dominos.co.in/store-locations/daman'],
['Restaurants in Darbhanga','https://www.dominos.co.in/store-locations/darbhanga'],
['Restaurants in Darjeeling','https://www.dominos.co.in/store-locations/darjeeling'],
['Restaurants in Davangere','https://www.dominos.co.in/store-locations/davangere'],
['Restaurants in Dehradun','https://www.dominos.co.in/store-locations/dehradun'],
['Restaurants in Dewas','https://www.dominos.co.in/store-locations/dewas'],
['Restaurants in Dhanbad','https://www.dominos.co.in/store-locations/dhanbad'],
['Restaurants in Dharamshala','https://www.dominos.co.in/store-locations/dharamshala'],
['Restaurants in Dharwad','https://www.dominos.co.in/store-locations/dharwad'],
['Restaurants in Dhule','https://www.dominos.co.in/store-locations/dhule'],
['Restaurants in Dibrugarh','https://www.dominos.co.in/store-locations/dibrugarh'],
['Restaurants in Dimapur','https://www.dominos.co.in/store-locations/dimapur'],
['Restaurants in Dombivali','https://www.dominos.co.in/store-locations/dombivali'],
['Restaurants in Durg','https://www.dominos.co.in/store-locations/durg'],
['Restaurants in Durgapur','https://www.dominos.co.in/store-locations/durgapur'],
['Restaurants in Erode','https://www.dominos.co.in/store-locations/erode'],
['Restaurants in Faridabad','https://www.dominos.co.in/store-locations/faridabad'],
['Restaurants in Faridkot','https://www.dominos.co.in/store-locations/faridkot'],
['Restaurants in Firozpur','https://www.dominos.co.in/store-locations/firozpur'],
['Restaurants in Gajraula','https://www.dominos.co.in/store-locations/gajraula'],
['Restaurants in Gandhidham','https://www.dominos.co.in/store-locations/gandhidham'],
['Restaurants in Gandhinagar','https://www.dominos.co.in/store-locations/gandhinagar'],
['Restaurants in Gangtok','https://www.dominos.co.in/store-locations/gangtok'],
['Restaurants in Gaya','https://www.dominos.co.in/store-locations/gaya'],
['Restaurants in Ghaziabad','https://www.dominos.co.in/store-locations/ghaziabad'],
['Restaurants in Gorakhpur','https://www.dominos.co.in/store-locations/gorakhpur'],
['Restaurants in Greater Noida','https://www.dominos.co.in/store-locations/greater-noida'],
['Restaurants in Gulbarga','https://www.dominos.co.in/store-locations/gulbarga'],
['Restaurants in Guntur','https://www.dominos.co.in/store-locations/guntur'],
['Restaurants in Gurgaon','https://www.dominos.co.in/store-locations/gurgaon'],
['Restaurants in Gwalior','https://www.dominos.co.in/store-locations/gwalior'],
['Restaurants in Hajipur','https://www.dominos.co.in/store-locations/hajipur'],
['Restaurants in Haldia','https://www.dominos.co.in/store-locations/haldia'],
['Restaurants in Haldwani','https://www.dominos.co.in/store-locations/haldwani'],
['Restaurants in Hapur','https://www.dominos.co.in/store-locations/hapur'],
['Restaurants in Harda','https://www.dominos.co.in/store-locations/harda'],
['Restaurants in Haridwar','https://www.dominos.co.in/store-locations/haridwar'],
['Restaurants in Hazaribagh','https://www.dominos.co.in/store-locations/hazaribagh'],
['Restaurants in Hissar','https://www.dominos.co.in/store-locations/hissar'],
['Restaurants in Hoogly','https://www.dominos.co.in/store-locations/hoogly'],
['Restaurants in Hoshiarpur','https://www.dominos.co.in/store-locations/hoshiarpur'],
['Restaurants in Hosur','https://www.dominos.co.in/store-locations/hosur'],
['Restaurants in Howrah','https://www.dominos.co.in/store-locations/howrah'],
['Restaurants in Hubli','https://www.dominos.co.in/store-locations/hubli'],
['Restaurants in Indore','https://www.dominos.co.in/store-locations/indore'],
['Restaurants in Itanagar','https://www.dominos.co.in/store-locations/itanagar'],
['Restaurants in Jabalpur','https://www.dominos.co.in/store-locations/jabalpur'],
['Restaurants in Jaigaon','https://www.dominos.co.in/store-locations/jaigaon'],
['Restaurants in Jalandhar','https://www.dominos.co.in/store-locations/jalandhar'],
['Restaurants in Jalgaon','https://www.dominos.co.in/store-locations/jalgaon'],
['Restaurants in Jam Nagar','https://www.dominos.co.in/store-locations/jam-nagar'],
['Restaurants in Jammu','https://www.dominos.co.in/store-locations/jammu'],
['Restaurants in Jamshedpur','https://www.dominos.co.in/store-locations/jamshedpur'],
['Restaurants in Jhansi','https://www.dominos.co.in/store-locations/jhansi'],
['Restaurants in Jodhpur','https://www.dominos.co.in/store-locations/jodhpur'],
['Restaurants in Jorhat','https://www.dominos.co.in/store-locations/jorhat'],
['Restaurants in Junagadh','https://www.dominos.co.in/store-locations/junagadh'],
['Restaurants in Kadapa','https://www.dominos.co.in/store-locations/kadapa'],
['Restaurants in Kaithal','https://www.dominos.co.in/store-locations/kaithal'],
['Restaurants in Kakinada','https://www.dominos.co.in/store-locations/kakinada'],
['Restaurants in Kanchipuram','https://www.dominos.co.in/store-locations/kanchipuram'],
['Restaurants in Kangra','https://www.dominos.co.in/store-locations/kangra'],
['Restaurants in Kanpur','https://www.dominos.co.in/store-locations/kanpur'],
['Restaurants in Kapurthala','https://www.dominos.co.in/store-locations/kapurthala'],
['Restaurants in Karad','https://www.dominos.co.in/store-locations/karad'],
['Restaurants in Karnal','https://www.dominos.co.in/store-locations/karnal'],
['Restaurants in Kashipur','https://www.dominos.co.in/store-locations/kashipur'],
['Restaurants in Katni','https://www.dominos.co.in/store-locations/katni'],
['Restaurants in Katra','https://www.dominos.co.in/store-locations/katra'],
['Restaurants in Khandwa','https://www.dominos.co.in/store-locations/khandwa'],
['Restaurants in Khanna','https://www.dominos.co.in/store-locations/khanna'],
['Restaurants in Kharagpur','https://www.dominos.co.in/store-locations/kharagpur'],
['Restaurants in Kharar','https://www.dominos.co.in/store-locations/kharar'],
['Restaurants in Kochi','https://www.dominos.co.in/store-locations/kochi'],
['Restaurants in Kodaikanal','https://www.dominos.co.in/store-locations/kodaikanal'],
['Restaurants in Kolhapur','https://www.dominos.co.in/store-locations/kolhapur'],
['Restaurants in Kollam','https://www.dominos.co.in/store-locations/kollam'],
['Restaurants in Korba','https://www.dominos.co.in/store-locations/korba'],
['Restaurants in Kota','https://www.dominos.co.in/store-locations/kota'],
['Restaurants in Kottayam','https://www.dominos.co.in/store-locations/kottayam'],
['Restaurants in Kullu','https://www.dominos.co.in/store-locations/kullu'],
['Restaurants in Kurnool','https://www.dominos.co.in/store-locations/kurnool'],
['Restaurants in Kurukshetra','https://www.dominos.co.in/store-locations/kurukshetra'],
['Restaurants in Latur','https://www.dominos.co.in/store-locations/latur'],
['Restaurants in Lonavala','https://www.dominos.co.in/store-locations/lonavala'],
['Restaurants in Ludhiana','https://www.dominos.co.in/store-locations/ludhiana'],
['Restaurants in Madikeri','https://www.dominos.co.in/store-locations/madikeri'],
['Restaurants in Madurai','https://www.dominos.co.in/store-locations/madurai'],
['Restaurants in Mahabaleshwar','https://www.dominos.co.in/store-locations/mahabaleshwar'],
['Restaurants in Mandi','https://www.dominos.co.in/store-locations/mandi'],
['Restaurants in Manesar','https://www.dominos.co.in/store-locations/manesar'],
['Restaurants in Mangalore','https://www.dominos.co.in/store-locations/mangalore'],
['Restaurants in Manipal','https://www.dominos.co.in/store-locations/manipal'],
['Restaurants in Mathura','https://www.dominos.co.in/store-locations/mathura'],
['Restaurants in Meerut','https://www.dominos.co.in/store-locations/meerut'],
['Restaurants in Mehsana','https://www.dominos.co.in/store-locations/mehsana'],
['Restaurants in Miraj','https://www.dominos.co.in/store-locations/miraj'],
['Restaurants in Moga','https://www.dominos.co.in/store-locations/moga'],
['Restaurants in Mohali','https://www.dominos.co.in/store-locations/mohali'],
['Restaurants in Moradabad','https://www.dominos.co.in/store-locations/moradabad'],
['Restaurants in Mount Abu','https://www.dominos.co.in/store-locations/mount-abu'],
['Restaurants in Mughalsarai','https://www.dominos.co.in/store-locations/mughalsarai'],
['Restaurants in Muzaffarnagar','https://www.dominos.co.in/store-locations/muzaffarnagar'],
['Restaurants in Muzzafarpur','https://www.dominos.co.in/store-locations/muzzafarpur'],
['Restaurants in Nadiad','https://www.dominos.co.in/store-locations/nadiad'],
['Restaurants in Nagaon','https://www.dominos.co.in/store-locations/nagaon'],
['Restaurants in Nagpur','https://www.dominos.co.in/store-locations/nagpur'],
['Restaurants in Nanded','https://www.dominos.co.in/store-locations/nanded'],
['Restaurants in Nasik','https://www.dominos.co.in/store-locations/nasik'],
['Restaurants in Navi Mumbai','https://www.dominos.co.in/store-locations/navi-mumbai'],
['Restaurants in Navsari','https://www.dominos.co.in/store-locations/navsari'],
['Restaurants in Nawanshahr','https://www.dominos.co.in/store-locations/nawanshahr'],
['Restaurants in Neemuch','https://www.dominos.co.in/store-locations/neemuch'],
['Restaurants in Nellore','https://www.dominos.co.in/store-locations/nellore'],
['Restaurants in Noida','https://www.dominos.co.in/store-locations/noida'],
['Restaurants in Ooty','https://www.dominos.co.in/store-locations/ooty'],
['Restaurants in Palakkad','https://www.dominos.co.in/store-locations/palakkad'],
['Restaurants in Palampur','https://www.dominos.co.in/store-locations/palampur'],
['Restaurants in Palanpur','https://www.dominos.co.in/store-locations/palanpur'],
['Restaurants in Palwal','https://www.dominos.co.in/store-locations/palwal'],
['Restaurants in Panchkula','https://www.dominos.co.in/store-locations/panchkula'],
['Restaurants in Panipat','https://www.dominos.co.in/store-locations/panipat'],
['Restaurants in Pathankot','https://www.dominos.co.in/store-locations/pathankot'],
['Restaurants in Patiala','https://www.dominos.co.in/store-locations/patiala'],
['Restaurants in Phagwara','https://www.dominos.co.in/store-locations/phagwara'],
['Restaurants in Pinjore','https://www.dominos.co.in/store-locations/pinjore'],
['Restaurants in Pondicherry','https://www.dominos.co.in/store-locations/pondicherry'],
['Restaurants in Puri','https://www.dominos.co.in/store-locations/puri'],
['Restaurants in Purnia','https://www.dominos.co.in/store-locations/purnia'],
['Restaurants in Raebareli','https://www.dominos.co.in/store-locations/raebareli'],
['Restaurants in Raigarh','https://www.dominos.co.in/store-locations/raigarh'],
['Restaurants in Raipur','https://www.dominos.co.in/store-locations/raipur'],
['Restaurants in Rajahamundry','https://www.dominos.co.in/store-locations/rajahamundry'],
['Restaurants in Rajkot','https://www.dominos.co.in/store-locations/rajkot'],
['Restaurants in Rajnandgaon','https://www.dominos.co.in/store-locations/rajnandgaon'],
['Restaurants in Rajpura','https://www.dominos.co.in/store-locations/rajpura'],
['Restaurants in Ranchi','https://www.dominos.co.in/store-locations/ranchi'],
['Restaurants in Ratlam','https://www.dominos.co.in/store-locations/ratlam'],
['Restaurants in Ratnagiri','https://www.dominos.co.in/store-locations/ratnagiri'],
['Restaurants in Rewa','https://www.dominos.co.in/store-locations/rewa'],
['Restaurants in Rewari','https://www.dominos.co.in/store-locations/rewari'],
['Restaurants in Rishikesh','https://www.dominos.co.in/store-locations/rishikesh'],
['Restaurants in Rohtak','https://www.dominos.co.in/store-locations/rohtak'],
['Restaurants in Roorkee','https://www.dominos.co.in/store-locations/roorkee'],
['Restaurants in Rourkela','https://www.dominos.co.in/store-locations/rourkela'],
['Restaurants in Rudrapur','https://www.dominos.co.in/store-locations/rudrapur'],
['Restaurants in Sagar','https://www.dominos.co.in/store-locations/sagar'],
['Restaurants in Saharanpur','https://www.dominos.co.in/store-locations/saharanpur'],
['Restaurants in Salem','https://www.dominos.co.in/store-locations/salem'],
['Restaurants in Sambalpur','https://www.dominos.co.in/store-locations/sambalpur'],
['Restaurants in Sangli','https://www.dominos.co.in/store-locations/sangli'],
['Restaurants in Sangrur','https://www.dominos.co.in/store-locations/sangrur'],
['Restaurants in Satara','https://www.dominos.co.in/store-locations/satara'],
['Restaurants in Satna','https://www.dominos.co.in/store-locations/satna'],
['Restaurants in Shahjahanpur','https://www.dominos.co.in/store-locations/shahjahanpur'],
['Restaurants in Shillong','https://www.dominos.co.in/store-locations/shillong'],
['Restaurants in Shimla','https://www.dominos.co.in/store-locations/shimla'],
['Restaurants in Shimoga','https://www.dominos.co.in/store-locations/shimoga'],
['Restaurants in Shirdi','https://www.dominos.co.in/store-locations/shirdi'],
['Restaurants in Sikkim','https://www.dominos.co.in/store-locations/sikkim'],
['Restaurants in Silchar','https://www.dominos.co.in/store-locations/silchar'],
['Restaurants in Siliguri','https://www.dominos.co.in/store-locations/siliguri'],
['Restaurants in Sirsa','https://www.dominos.co.in/store-locations/sirsa'],
['Restaurants in Solan','https://www.dominos.co.in/store-locations/solan'],
['Restaurants in Solapur','https://www.dominos.co.in/store-locations/solapur'],
['Restaurants in Sonipat','https://www.dominos.co.in/store-locations/sonipat'],
['Restaurants in Sreerampore','https://www.dominos.co.in/store-locations/sreerampore'],
['Restaurants in Sri Ganganagar','https://www.dominos.co.in/store-locations/sri-ganganagar'],
['Restaurants in Surat','https://www.dominos.co.in/store-locations/surat'],
['Restaurants in Surendranagar','https://www.dominos.co.in/store-locations/surendranagar'],
['Restaurants in Tezpur','https://www.dominos.co.in/store-locations/tezpur'],
['Restaurants in Thane','https://www.dominos.co.in/store-locations/thane'],
['Restaurants in Thanjavur','https://www.dominos.co.in/store-locations/thanjavur'],
['Restaurants in Thrissur','https://www.dominos.co.in/store-locations/thrissur'],
['Restaurants in Tinsukia','https://www.dominos.co.in/store-locations/tinsukia'],
['Restaurants in Tiruchirapalli','https://www.dominos.co.in/store-locations/tiruchirapalli'],
['Restaurants in Tirunelvelli','https://www.dominos.co.in/store-locations/tirunelvelli'],
['Restaurants in Tirupati','https://www.dominos.co.in/store-locations/tirupati'],
['Restaurants in Tirupur','https://www.dominos.co.in/store-locations/tirupur'],
['Restaurants in Trivandrum','https://www.dominos.co.in/store-locations/trivandrum'],
['Restaurants in Tumkur','https://www.dominos.co.in/store-locations/tumkur'],
['Restaurants in Udaipur','https://www.dominos.co.in/store-locations/udaipur'],
['Restaurants in Ujjain','https://www.dominos.co.in/store-locations/ujjain'],
['Restaurants in Vadodara','https://www.dominos.co.in/store-locations/vadodara'],
['Restaurants in Valsad','https://www.dominos.co.in/store-locations/valsad'],
['Restaurants in Vapi','https://www.dominos.co.in/store-locations/vapi'],
['Restaurants in Varanasi','https://www.dominos.co.in/store-locations/varanasi'],
['Restaurants in Vellore','https://www.dominos.co.in/store-locations/vellore'],
['Restaurants in Vijayawada','https://www.dominos.co.in/store-locations/vijayawada'],
['Restaurants in Vishakhapatnam','https://www.dominos.co.in/store-locations/vishakhapatnam'],
['Restaurants in Vizianagaram','https://www.dominos.co.in/store-locations/vizianagaram'],
['Restaurants in Warangal','https://www.dominos.co.in/store-locations/warangal'],
['Restaurants in Wardha','https://www.dominos.co.in/store-locations/wardha'],
['Restaurants in Yamuna Nagar','https://www.dominos.co.in/store-locations/yamuna-nagar'],
['Restaurants in Yavatmal','https://www.dominos.co.in/store-locations/yavatmal'],
['Restaurants in Zirakpur','https://www.dominos.co.in/store-locations/zirakpur'],
];
var shuffled = fisherYates(activities);
var html =  '';
for(var i = 0; i < 10; i++) {
   html +='<span class="link-item shuffle test-label label-default"><a href="'+shuffled[i][1]+'" target="_blank">'+shuffled[i][0]+'</a></span>';
    
}
$('#container-store').append(html);
    })
    
    function fisherYates(myArray) {
var i = myArray.length, j, tempi, tempj;
if (i === 0) return false;
while (--i) {
    j = Math.floor(Math.random() * (i + 1));
    tempi = myArray[i];
    tempj = myArray[j];
    myArray[i] = tempj;
    myArray[j] = tempi;
}
return myArray;
}
</script>
<style>
.content-h3{
  color: #006491!important;
    background: 0 0;
    border-width: 0;
    font-family: One Dot;
    font-size: 30px;
    line-height: 34px;
    font-weight: 400;
    font-family: "One Dot","DIN Condensed","Bahnschrift Condensed","Roboto Condensed","Arial Narrow",sans-serif;
    font-weight: 700;
    text-transform: uppercase;
}
.content-p{
    color: #54565b;
    background: 0 0;
    border-width: 0;
    font-family: Arial;
    font-size: 16px;
    line-height: 26px;
    font-weight: 400;
}
/* Add a slash symbol (/) before/behind each list item */
ul.breadcrumb li+li:before {
  padding: 8px!important;
  color: black!important;
  content: "/\00a0";
}

/* Add a color to all links inside the list */
ul.breadcrumb li a {
  color: #0275d8!important;
  text-decoration: none!important;
  text-transform:capitalize!important;
}

/* Add a color on mouse-over */
ul.breadcrumb li a:hover {
  color: #01447e!important;
  text-decoration: underline!important;
}
</style>    </div>
            <!-- Advertiser 'BLAZAR- (UNIT OF QUASAR MEDIA PVT LTD) - JUBILANT FOODWORKS LTD',  Include user in segment 'Site Retargeting Pixel' - DO NOT MODIFY THIS PIXEL IN ANY WAY -->
        <img src="https://ad.yieldmanager.com/pixel?id=1338851&amp;t=2" width="1" height="1" alt="" />
        <!-- End of segment tag -->
       
  <script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"NRBR-3e999030a12e14fece2","applicationID":"685069429","transactionName":"YlcAZEAHXEYHVhBfXFsdN0JbSVtbAlAcGENdQg==","queueTime":0,"applicationTime":22,"atts":"ThADEggdT0g=","errorBeacon":"bam.nr-data.net","agent":""}</script></body>    
  <style>
    @media (min-width: 768px)
.col-md-12 {
    -ms-flex: 0 0 100%;
    flex: 0 0 100%;
    max-width: 100%;
}
}
.st-box-white {
    background-color: #fff;
    padding: 10px 15px;
    border-radius: 4px;
    overflow: hidden;
}
.st-accordion .card {
    border: 0;
    border-top: 1px solid rgba(0,0,0,.125);
}
.card {
    position: relative;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-direction: column;
    flex-direction: column;
    min-width: 0;
    word-wrap: break-word;
    background-color: #fff;
    background-clip: border-box;
    border: 1px solid rgba(0,0,0,.125);
    border-radius: 0.25rem;
}
.st-accordion .card-header {
    background-color: #fafafa;
    border: 0;
}

.card-header:first-child {
    border-radius: calc(0.25rem - 1px) calc(0.25rem - 1px) 0 0;
}
.card-header {
    padding: 0.75rem 1.25rem;
    margin-bottom: 0;
    background-color: rgba(0,0,0,.03);
    border-bottom: 1px solid rgba(0,0,0,.125);
}
.collapsed{
  color:black;
}

  </style>      
</html>
